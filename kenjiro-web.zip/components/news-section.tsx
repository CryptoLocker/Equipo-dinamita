import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar } from "lucide-react"

export default function NewsSection() {
  const news = [
    {
      id: 1,
      title: "Inicio del Año Escolar 2024",
      description:
        "Información importante sobre el inicio de clases y las actividades programadas para el nuevo año escolar.",
      date: "2024-01-15",
      category: "Institucional",
      image: "/placeholder.svg?height=200&width=400",
      slug: "inicio-ano-escolar-2024",
    },
    {
      id: 2,
      title: "Olimpiadas de Matemáticas",
      description:
        "Nuestros estudiantes participarán en las olimpiadas regionales de matemáticas. ¡Prepárate para representar a INEDJAS!",
      date: "2024-02-10",
      category: "Académico",
      image: "/placeholder.svg?height=200&width=400",
      slug: "olimpiadas-matematicas",
    },
    {
      id: 3,
      title: "Feria de Ciencias y Tecnología",
      description: "Participa en nuestra feria anual de ciencias y tecnología presentando tus proyectos innovadores.",
      date: "2024-03-05",
      category: "Eventos",
      image: "/placeholder.svg?height=200&width=400",
      slug: "feria-ciencias-tecnologia",
    },
  ]

  return (
    <section className="py-12 bg-accent/5">
      <div className="container">
        <div className="flex flex-col md:flex-row justify-between items-center mb-8">
          <div>
            <h2 className="text-3xl font-bold text-primary">Noticias y Eventos</h2>
            <p className="text-muted-foreground">
              Mantente informado sobre las últimas novedades de nuestra institución
            </p>
          </div>
          <Button
            variant="outline"
            className="mt-4 md:mt-0 border-accent text-accent-foreground hover:bg-accent/10"
            asChild
          >
            <Link href="/noticias">Ver todas las noticias</Link>
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {news.map((item) => (
            <Card key={item.id} className="overflow-hidden flex flex-col h-full border-t-4 border-primary">
              <div className="relative h-48 w-full">
                <Image src={item.image || "/placeholder.svg"} alt={item.title} fill className="object-cover" />
              </div>
              <CardHeader>
                <div className="flex justify-between items-center mb-2">
                  <Badge variant="secondary">{item.category}</Badge>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Calendar className="h-3.5 w-3.5 mr-1" />
                    {formatDate(item.date)}
                  </div>
                </div>
                <CardTitle>{item.title}</CardTitle>
                <CardDescription>{item.description}</CardDescription>
              </CardHeader>
              <CardFooter className="mt-auto">
                <Button variant="link" asChild className="px-0">
                  <Link href={`/noticias/${item.slug}`}>Leer más</Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

function formatDate(dateString: string) {
  const options: Intl.DateTimeFormatOptions = { year: "numeric", month: "long", day: "numeric" }
  return new Date(dateString).toLocaleDateString("es-ES", options)
}

