import { Book, Calendar, FileText, Headphones, MessageSquare, Radio, Users } from "lucide-react"

export default function FeaturesSection() {
  const features = [
    {
      icon: <Users className="h-10 w-10" />,
      title: "Información Institucional",
      description: "Conoce nuestra misión, visión y valores que guían nuestra labor educativa.",
    },
    {
      icon: <Book className="h-10 w-10" />,
      title: "Plataforma Académica",
      description: "Acceso a calificaciones, tareas y recursos educativos en línea.",
    },
    {
      icon: <FileText className="h-10 w-10" />,
      title: "Manual de Convivencia",
      description: "Normas y reglamentos que rigen nuestra comunidad educativa.",
    },
    {
      icon: <Radio className="h-10 w-10" />,
      title: "Emisora Escolar",
      description: "Programas y contenidos producidos por nuestros estudiantes.",
    },
    {
      icon: <Headphones className="h-10 w-10" />,
      title: "Periódico Escolar",
      description: "Noticias, artículos y reportajes escritos por la comunidad.",
    },
    {
      icon: <Calendar className="h-10 w-10" />,
      title: "Calendario de Eventos",
      description: "Mantente al día con todas las actividades programadas.",
    },
    {
      icon: <FileText className="h-10 w-10" />,
      title: "Trámites",
      description: "Información sobre certificados y documentos administrativos.",
    },
    {
      icon: <MessageSquare className="h-10 w-10" />,
      title: "Contacto",
      description: "Información para comunicarte con nuestra institución.",
    },
  ]

  return (
    <section className="py-16 bg-secondary/5">
      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl font-bold mb-4 text-primary">Nuestros Servicios</h2>
          <p className="text-muted-foreground">
            Ofrecemos una variedad de servicios y herramientas para facilitar la comunicación y el aprendizaje en
            nuestra comunidad educativa.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-card rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow flex flex-col items-center text-center border-t-4 border-primary"
            >
              <div className="text-primary mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

