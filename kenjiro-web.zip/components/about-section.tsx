import { Button } from "@/components/ui/button"
import Link from "next/link"
import Image from "next/image"

export default function AboutSection() {
  return (
    <section className="py-16 bg-gradient-to-b from-primary/5 to-accent/5">
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl font-bold mb-6 text-primary">Conozca Nuestra Institución</h2>
            <p className="text-lg mb-6 text-muted-foreground">
              La Institución Educativa Distrital Juan Acosta Solera es un centro educativo comprometido con la formación
              integral de niños, niñas y jóvenes, promoviendo valores, excelencia académica y responsabilidad social.
            </p>
            <p className="text-lg mb-6 text-muted-foreground">
              Fundada en 1985, nuestra institución ha sido un pilar en la comunidad educativa de Barranquilla, formando
              generaciones de estudiantes que hoy son profesionales exitosos y ciudadanos comprometidos.
            </p>
            <Button asChild className="bg-primary hover:bg-primary/90">
              <Link href="/acerca">Conocer más</Link>
            </Button>
          </div>
          <div className="relative h-[400px] rounded-xl overflow-hidden shadow-xl border-4 border-accent/20">
            <Image
              src="/placeholder.svg?height=400&width=600"
              alt="Institución Educativa"
              fill
              className="object-cover"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-16">
          <div className="bg-white dark:bg-primary/10 p-8 rounded-xl shadow-lg border-l-4 border-primary">
            <h3 className="text-2xl font-bold mb-4 text-primary">Nuestra Misión</h3>
            <p className="text-muted-foreground">
              Formar integralmente a niños, niñas y jóvenes con altos estándares académicos, valores éticos y morales,
              capacidad crítica y compromiso social, preparándolos para enfrentar los retos del mundo contemporáneo y
              contribuir positivamente a la transformación de su entorno.
            </p>
          </div>
          <div className="bg-white dark:bg-accent/10 p-8 rounded-xl shadow-lg border-l-4 border-accent">
            <h3 className="text-2xl font-bold mb-4 text-accent-foreground">Nuestra Visión</h3>
            <p className="text-muted-foreground">
              Para el año 2030, la Institución Educativa Distrital Juan Acosta Solera será reconocida a nivel regional y
              nacional como un referente de excelencia educativa, innovación pedagógica y formación en valores,
              destacándose por el alto desempeño académico de sus estudiantes y su impacto positivo en la comunidad.
            </p>
          </div>
        </div>

        <div className="mt-16 bg-secondary/10 p-8 rounded-xl shadow-lg border-l-4 border-secondary">
          <h3 className="text-2xl font-bold mb-4 text-secondary-foreground">Nuestro Lema</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4">
              <div className="w-16 h-16 mx-auto mb-3 rounded-full bg-primary/10 flex items-center justify-center">
                <span className="text-2xl font-bold text-primary">A</span>
              </div>
              <h4 className="font-semibold">Actitud</h4>
            </div>
            <div className="text-center p-4">
              <div className="w-16 h-16 mx-auto mb-3 rounded-full bg-accent/10 flex items-center justify-center">
                <span className="text-2xl font-bold text-accent-foreground">L</span>
              </div>
              <h4 className="font-semibold">Liderazgo</h4>
            </div>
            <div className="text-center p-4">
              <div className="w-16 h-16 mx-auto mb-3 rounded-full bg-secondary/10 flex items-center justify-center">
                <span className="text-2xl font-bold text-secondary-foreground">C</span>
              </div>
              <h4 className="font-semibold">Conocimiento</h4>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

