import type React from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, Headphones, Mic, Radio, Users, Music, Play, Volume2, Instagram } from "lucide-react"

export default function EmisoraPage() {
  return (
    <main className="container py-12">
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-col items-center mb-10 text-center">
          <div className="relative w-24 h-24 rounded-full overflow-hidden border-4 border-accent mb-6 shadow-md">
            <Image
              src="/logo-inedjas.png"
              alt="Logo INEDJAS"
              fill
              className="object-contain p-2 rounded-full"
              priority
            />
          </div>
          <h1 className="text-4xl font-bold mb-4">Emisora Escolar</h1>
          <p className="text-xl text-muted-foreground max-w-3xl">
            La Voz INEDJAS: Un espacio de expresión, creatividad y aprendizaje para nuestra comunidad educativa
          </p>
        </div>

        {/* Hero Section */}
        <div className="relative rounded-xl overflow-hidden mb-12 h-[400px]">
          <Image
            src="/images/emisora-1.png"
            alt="Estudiantes en la emisora escolar"
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-end p-8">
            <Badge className="mb-2 bg-accent text-accent-foreground">En vivo</Badge>
            <h2 className="text-3xl font-bold text-white mb-2">La Voz INEDJAS</h2>
            <p className="text-white/90 max-w-2xl">
              Nuestra emisora escolar, un proyecto pedagógico que promueve la comunicación, el trabajo en equipo y el
              desarrollo de habilidades comunicativas en nuestros estudiantes.
            </p>
            <div className="flex gap-4 mt-4">
              <Button className="gap-2" size="lg">
                <Play className="h-4 w-4" /> Escuchar ahora
              </Button>
              <Button
                variant="outline"
                className="gap-2 bg-white/20 text-white border-white/40 hover:bg-white/30 hover:text-white"
                size="lg"
              >
                <Calendar className="h-4 w-4" /> Ver programación
              </Button>
            </div>
          </div>
        </div>

        <Tabs defaultValue="acerca" className="mb-12">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="acerca">Acerca de</TabsTrigger>
            <TabsTrigger value="programas">Programas</TabsTrigger>
            <TabsTrigger value="equipo">Equipo</TabsTrigger>
            <TabsTrigger value="galeria">Galería</TabsTrigger>
          </TabsList>

          <TabsContent value="acerca">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Radio className="h-5 w-5 text-primary" />
                  Nuestra Emisora
                </CardTitle>
                <CardDescription>
                  Conoce más sobre la emisora escolar de la Institución Educativa Distrital Juan Acosta Solera
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                  <div>
                    <h3 className="text-xl font-semibold mb-4 text-primary">¿Qué es La Voz INEDJAS?</h3>
                    <p className="text-muted-foreground mb-4">
                      La Voz INEDJAS es la emisora escolar de nuestra institución, un proyecto pedagógico que nació en
                      2010 con el objetivo de brindar a los estudiantes un espacio de expresión, creatividad y
                      aprendizaje a través de la radio.
                    </p>
                    <p className="text-muted-foreground">
                      Este proyecto busca desarrollar habilidades comunicativas, fomentar el trabajo en equipo, promover
                      la investigación y estimular la creatividad de nuestros estudiantes, convirtiéndose en un
                      importante medio de comunicación para toda la comunidad educativa.
                    </p>
                  </div>
                  <div className="bg-muted rounded-lg p-6 space-y-4">
                    <h4 className="font-semibold flex items-center gap-2">
                      <Volume2 className="h-5 w-5 text-primary" /> Objetivos de la emisora
                    </h4>
                    <ul className="space-y-2">
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Desarrollar habilidades comunicativas en los estudiantes</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Fomentar el trabajo en equipo y la responsabilidad</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Promover la investigación y el pensamiento crítico</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Difundir información relevante para la comunidad educativa</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Estimular la creatividad y el talento de los estudiantes</span>
                      </li>
                    </ul>
                  </div>
                </div>

                <div className="mt-8">
                  <h3 className="text-xl font-semibold mb-4 text-primary">Funcionamiento</h3>
                  <p className="text-muted-foreground mb-4">
                    La emisora escolar funciona durante los descansos y en horarios especiales programados por la
                    institución. Cuenta con un equipo de estudiantes de diferentes grados que, bajo la orientación de
                    docentes, se encargan de la producción, locución y operación técnica de los programas.
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                    <div className="bg-white dark:bg-primary/5 p-4 rounded-lg border border-border">
                      <h4 className="font-semibold mb-2 flex items-center gap-2">
                        <Clock className="h-4 w-4 text-primary" /> Horarios de transmisión
                      </h4>
                      <ul className="space-y-1 text-muted-foreground">
                        <li>• Primer descanso: 9:30 AM - 10:00 AM</li>
                        <li>• Segundo descanso: 12:00 PM - 12:30 PM</li>
                        <li>• Programas especiales: Viernes 2:00 PM - 3:00 PM</li>
                      </ul>
                    </div>
                    <div className="bg-white dark:bg-primary/5 p-4 rounded-lg border border-border">
                      <h4 className="font-semibold mb-2 flex items-center gap-2">
                        <Mic className="h-4 w-4 text-primary" /> Equipamiento
                      </h4>
                      <ul className="space-y-1 text-muted-foreground">
                        <li>• Consola de audio profesional</li>
                        <li>• Micrófonos dinámicos con brazos articulados</li>
                        <li>• Computadoras con software de edición</li>
                        <li>• Sistema de amplificación para toda la institución</li>
                      </ul>
                    </div>
                    <div className="bg-white dark:bg-primary/5 p-4 rounded-lg border border-border">
                      <h4 className="font-semibold mb-2 flex items-center gap-2">
                        <Users className="h-4 w-4 text-primary" /> Participación
                      </h4>
                      <ul className="space-y-1 text-muted-foreground">
                        <li>• Abierta a estudiantes de 6° a 11° grado</li>
                        <li>• Proceso de selección semestral</li>
                        <li>• Capacitación continua</li>
                        <li>• Reconocimiento académico por participación</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="mt-8">
                  <h3 className="text-xl font-semibold mb-4 text-primary">Impacto Educativo</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div>
                      <p className="text-muted-foreground mb-4">
                        La emisora escolar ha tenido un impacto significativo en el desarrollo de competencias
                        comunicativas de nuestros estudiantes, mejorando su expresión oral, capacidad de síntesis,
                        investigación y trabajo colaborativo.
                      </p>
                      <p className="text-muted-foreground">
                        Además, se ha convertido en un importante canal de comunicación para toda la comunidad
                        educativa, fortaleciendo el sentido de pertenencia y la identidad institucional.
                      </p>
                    </div>
                    <div className="relative h-[200px] rounded-lg overflow-hidden">
                      <Image
                        src="/images/emisora-2.png"
                        alt="Estudiantes trabajando en la emisora"
                        fill
                        className="object-cover"
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="programas">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Headphones className="h-5 w-5 text-primary" />
                  Programación
                </CardTitle>
                <CardDescription>
                  Conoce los diferentes programas que se transmiten en nuestra emisora escolar
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <ProgramCard
                    title="Noticias INEDJAS"
                    description="Información actualizada sobre eventos, actividades y noticias relevantes para nuestra comunidad educativa."
                    schedule="Lunes a Viernes - Primer descanso"
                    hosts="Estudiantes de 10° y 11°"
                    icon={<Radio className="h-10 w-10" />}
                  />
                  <ProgramCard
                    title="Cultura y Arte"
                    description="Espacio dedicado a la difusión de manifestaciones artísticas y culturales, tanto de nuestra institución como del contexto local y nacional."
                    schedule="Martes - Segundo descanso"
                    hosts="Club de Arte y Literatura"
                    icon={<Music className="h-10 w-10" />}
                  />
                  <ProgramCard
                    title="Ciencia al Día"
                    description="Programa que busca acercar la ciencia a los estudiantes de manera amena y comprensible, con experimentos, curiosidades y avances científicos."
                    schedule="Miércoles - Segundo descanso"
                    hosts="Club de Ciencias"
                    icon={<Radio className="h-10 w-10" />}
                  />
                  <ProgramCard
                    title="Deportes INEDJAS"
                    description="Toda la información deportiva de nuestra institución: resultados, próximos eventos, entrevistas a deportistas destacados y más."
                    schedule="Jueves - Segundo descanso"
                    hosts="Equipo deportivo"
                    icon={<Radio className="h-10 w-10" />}
                  />
                  <ProgramCard
                    title="Música y Tendencias"
                    description="Lo último en música, tecnología, cine y tendencias juveniles, con recomendaciones y análisis de los propios estudiantes."
                    schedule="Viernes - Ambos descansos"
                    hosts="Estudiantes de 8° y 9°"
                    icon={<Music className="h-10 w-10" />}
                  />
                  <ProgramCard
                    title="Voces de la Comunidad"
                    description="Espacio para entrevistas a miembros destacados de nuestra comunidad educativa y del entorno local."
                    schedule="Viernes - Programa especial"
                    hosts="Equipo de periodismo"
                    icon={<Radio className="h-10 w-10" />}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="equipo">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-primary" />
                  Nuestro Equipo
                </CardTitle>
                <CardDescription>
                  Conoce a los estudiantes y docentes que hacen posible la emisora escolar
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-8">
                  <h3 className="text-xl font-semibold mb-4 text-primary">Coordinación</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <TeamMemberCard
                      name="Prof. Carlos Martínez"
                      role="Coordinador General"
                      description="Docente de Lengua Castellana y coordinador del proyecto de emisora escolar desde 2015."
                    />
                    <TeamMemberCard
                      name="Prof. Laura Gómez"
                      role="Asesora de Contenidos"
                      description="Docente de Ciencias Sociales, encargada de supervisar y orientar los contenidos de los programas."
                    />
                    <TeamMemberCard
                      name="Prof. Juan Pérez"
                      role="Asesor Técnico"
                      description="Docente de Tecnología e Informática, responsable del soporte técnico y capacitación en equipos."
                    />
                  </div>
                </div>

                <div>
                  <h3 className="text-xl font-semibold mb-4 text-primary">Equipo Estudiantil</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <StudentCard name="Ana María Rodríguez" grade="11°" role="Directora" />
                    <StudentCard name="Carlos Sánchez" grade="11°" role="Productor" />
                    <StudentCard name="Valentina Torres" grade="10°" role="Locutora principal" />
                    <StudentCard name="Daniel Morales" grade="10°" role="Operador técnico" />
                    <StudentCard name="Sofía Ramírez" grade="9°" role="Reportera" />
                    <StudentCard name="Andrés Gómez" grade="9°" role="Locutor" />
                    <StudentCard name="Camila Vargas" grade="8°" role="Redactora" />
                    <StudentCard name="Sebastián López" grade="8°" role="Asistente técnico" />
                  </div>
                </div>

                <div className="mt-8 bg-muted p-6 rounded-lg">
                  <h3 className="text-xl font-semibold mb-4">¿Quieres formar parte del equipo?</h3>
                  <p className="mb-4">
                    Si eres estudiante de INEDJAS y te interesa participar en la emisora escolar, puedes inscribirte en
                    las convocatorias que se realizan al inicio de cada semestre.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4">
                    <Button asChild>
                      <Link href="/contacto">Más información</Link>
                    </Button>
                    <Button variant="outline">Descargar formulario</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="galeria">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Radio className="h-5 w-5 text-primary" />
                  Galería
                </CardTitle>
                <CardDescription>Imágenes de nuestra emisora escolar en acción</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <div className="relative h-[300px] rounded-lg overflow-hidden">
                      <Image
                        src="/images/emisora-1.png"
                        alt="Estudiantes en la emisora escolar"
                        fill
                        className="object-cover"
                      />
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Estudiantes de diferentes grados participando en la producción y locución de programas en nuestra
                      emisora "La Voz INEDJAS".
                    </p>
                  </div>
                  <div className="space-y-2">
                    <div className="relative h-[300px] rounded-lg overflow-hidden">
                      <Image
                        src="/images/emisora-2.png"
                        alt="Estudio de radio con estudiantes"
                        fill
                        className="object-cover"
                      />
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Nuestro moderno estudio de radio equipado con tecnología profesional para la formación de los
                      estudiantes en comunicación radiofónica.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="bg-primary/5 rounded-lg p-6 mb-8">
          <h2 className="text-2xl font-bold mb-4">Contacto</h2>
          <p className="mb-4">
            Para más información sobre la emisora escolar, puedes contactar al equipo de coordinación:
          </p>
          <div className="space-y-2">
            <p>
              <strong>Correo electrónico:</strong> emisora@inedjas.edu.co
            </p>
            <p>
              <strong>Ubicación:</strong> Bloque B, segundo piso, sala de emisora
            </p>
            <p>
              <strong>Horario de atención:</strong> Lunes a viernes durante los descansos
            </p>
          </div>
          <div className="mt-4">
            <Link
              href="https://www.instagram.com/escuelajuanacosta/"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-500 via-pink-500 to-yellow-500 text-white px-4 py-2 rounded-md hover:opacity-90 transition-opacity"
            >
              <Instagram className="h-5 w-5" />
              <span className="font-medium">Síguenos en Instagram</span>
            </Link>
          </div>
        </div>

        <div className="flex justify-center">
          <Button asChild>
            <Link href="/">Volver al inicio</Link>
          </Button>
        </div>
      </div>
    </main>
  )
}

function ProgramCard({
  title,
  description,
  schedule,
  hosts,
  icon,
}: {
  title: string
  description: string
  schedule: string
  hosts: string
  icon: React.ReactNode
}) {
  return (
    <div className="bg-white dark:bg-primary/5 p-6 rounded-lg border border-border">
      <div className="flex items-start gap-4">
        <div className="text-primary">{icon}</div>
        <div>
          <h3 className="text-lg font-semibold mb-2">{title}</h3>
          <p className="text-muted-foreground text-sm mb-4">{description}</p>
          <div className="space-y-1 text-sm">
            <p className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-primary" />
              <span>{schedule}</span>
            </p>
            <p className="flex items-center gap-2">
              <Users className="h-4 w-4 text-primary" />
              <span>{hosts}</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

function TeamMemberCard({
  name,
  role,
  description,
}: {
  name: string
  role: string
  description: string
}) {
  return (
    <div className="bg-white dark:bg-primary/5 p-6 rounded-lg border border-border">
      <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
        <Users className="h-8 w-8 text-primary" />
      </div>
      <h3 className="text-lg font-semibold text-center mb-1">{name}</h3>
      <p className="text-primary text-sm text-center mb-3">{role}</p>
      <p className="text-muted-foreground text-sm text-center">{description}</p>
    </div>
  )
}

function StudentCard({
  name,
  grade,
  role,
}: {
  name: string
  grade: string
  role: string
}) {
  return (
    <div className="bg-white dark:bg-primary/5 p-4 rounded-lg border border-border">
      <h4 className="font-medium">{name}</h4>
      <div className="flex justify-between text-sm text-muted-foreground">
        <span>{grade}</span>
        <span>{role}</span>
      </div>
    </div>
  )
}

