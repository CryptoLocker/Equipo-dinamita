import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookOpen, Download, FileText, Shield, Users } from "lucide-react"

export default function ConvivenciaPage() {
  return (
    <main className="container py-12">
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-col items-center mb-10 text-center">
          <div className="relative w-24 h-24 rounded-full overflow-hidden border-4 border-accent mb-6 shadow-md">
            <Image
              src="/logo-inedjas.png"
              alt="Logo INEDJAS"
              fill
              className="object-contain p-2 rounded-full"
              priority
            />
          </div>
          <h1 className="text-4xl font-bold mb-4">Manual de Convivencia</h1>
          <p className="text-xl text-muted-foreground max-w-3xl">
            Normas y principios que rigen nuestra comunidad educativa para una convivencia armónica y respetuosa
          </p>
        </div>

        <div className="bg-primary/5 p-8 rounded-xl mb-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-4 text-primary">Manual de Convivencia 2023-2024</h2>
              <p className="text-muted-foreground mb-4">
                El Manual de Convivencia es un documento que establece los principios, valores, derechos y deberes que
                orientan el comportamiento de los miembros de nuestra comunidad educativa.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button className="gap-2">
                  <Download className="h-4 w-4" /> Descargar PDF
                </Button>
                <Button variant="outline" className="gap-2">
                  <BookOpen className="h-4 w-4" /> Leer en línea
                </Button>
              </div>
            </div>
            <div className="relative h-[300px] rounded-lg overflow-hidden border-4 border-accent/20">
              <Image
                src="/placeholder.svg?height=300&width=400"
                alt="Manual de Convivencia"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>

        <Tabs defaultValue="principios" className="mb-12">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="principios">Principios</TabsTrigger>
            <TabsTrigger value="derechos">Derechos y Deberes</TabsTrigger>
            <TabsTrigger value="normas">Normas</TabsTrigger>
            <TabsTrigger value="procedimientos">Procedimientos</TabsTrigger>
          </TabsList>

          <TabsContent value="principios">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-primary" />
                  Principios y Valores
                </CardTitle>
                <CardDescription>Fundamentos que orientan nuestra convivencia escolar</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <p className="text-muted-foreground">
                  Nuestro Manual de Convivencia se fundamenta en principios y valores que promueven el respeto, la
                  responsabilidad, la tolerancia y la solidaridad entre todos los miembros de la comunidad educativa.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                  <div className="bg-muted p-6 rounded-lg">
                    <h3 className="text-lg font-semibold mb-4">Principios Fundamentales</h3>
                    <ul className="space-y-2">
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Respeto a la dignidad humana</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Prevalencia del interés general sobre el particular</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Participación democrática</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Debido proceso</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Inclusión y no discriminación</span>
                      </li>
                    </ul>
                  </div>
                  <div className="bg-muted p-6 rounded-lg">
                    <h3 className="text-lg font-semibold mb-4">Valores Institucionales</h3>
                    <ul className="space-y-2">
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Actitud: Disposición positiva ante los desafíos</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Liderazgo: Capacidad para influir positivamente</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Conocimiento: Búsqueda constante del saber</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Respeto: Reconocimiento de la dignidad de todos</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Responsabilidad: Cumplimiento de deberes y compromisos</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="derechos">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-primary" />
                  Derechos y Deberes
                </CardTitle>
                <CardDescription>Derechos y deberes de los miembros de la comunidad educativa</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="estudiantes">
                  <TabsList className="w-full">
                    <TabsTrigger value="estudiantes">Estudiantes</TabsTrigger>
                    <TabsTrigger value="docentes">Docentes</TabsTrigger>
                    <TabsTrigger value="padres">Padres de Familia</TabsTrigger>
                  </TabsList>

                  <TabsContent value="estudiantes" className="mt-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h3 className="text-lg font-semibold mb-4 text-primary">Derechos de los Estudiantes</h3>
                        <ul className="space-y-2">
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Recibir una educación de calidad</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Ser tratado con respeto y dignidad</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Participar en las actividades de la institución</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Expresar libremente sus opiniones</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Ser evaluado de manera justa y objetiva</span>
                          </li>
                        </ul>
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold mb-4 text-primary">Deberes de los Estudiantes</h3>
                        <ul className="space-y-2">
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Asistir puntualmente a clases</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Cumplir con las actividades académicas</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Respetar a todos los miembros de la comunidad</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Cuidar las instalaciones y recursos</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Portar adecuadamente el uniforme</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="docentes" className="mt-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h3 className="text-lg font-semibold mb-4 text-primary">Derechos de los Docentes</h3>
                        <ul className="space-y-2">
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Ser respetado en su dignidad personal y profesional</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Participar en la toma de decisiones institucionales</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Recibir capacitación y actualización profesional</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Contar con los recursos necesarios para su labor</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Ser evaluado de manera justa y objetiva</span>
                          </li>
                        </ul>
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold mb-4 text-primary">Deberes de los Docentes</h3>
                        <ul className="space-y-2">
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Cumplir con su jornada laboral y responsabilidades</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Brindar una educación de calidad</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Tratar con respeto a todos los miembros de la comunidad</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Participar en las actividades institucionales</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Mantener comunicación con padres de familia</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="padres" className="mt-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h3 className="text-lg font-semibold mb-4 text-primary">Derechos de los Padres</h3>
                        <ul className="space-y-2">
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Recibir información sobre el proceso educativo</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Participar en las actividades institucionales</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Ser atendidos por directivos y docentes</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Elegir y ser elegido en órganos de participación</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Recibir orientación sobre la educación de sus hijos</span>
                          </li>
                        </ul>
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold mb-4 text-primary">Deberes de los Padres</h3>
                        <ul className="space-y-2">
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Asistir a reuniones y citaciones</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Apoyar el proceso educativo de sus hijos</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Proporcionar los recursos necesarios</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Respetar a todos los miembros de la comunidad</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <span className="h-2 w-2 rounded-full bg-primary"></span>
                            </span>
                            <span>Cumplir con las obligaciones establecidas</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="normas">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-primary" />
                  Normas de Convivencia
                </CardTitle>
                <CardDescription>Normas que regulan la convivencia en nuestra institución</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <p className="text-muted-foreground">
                  Las normas de convivencia son pautas de comportamiento que buscan garantizar un ambiente escolar
                  armonioso, respetuoso y propicio para el aprendizaje.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                  <div className="bg-muted p-6 rounded-lg">
                    <h3 className="text-lg font-semibold mb-4">Presentación Personal</h3>
                    <ul className="space-y-2">
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Portar correctamente el uniforme según el horario</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Mantener una adecuada higiene personal</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>No usar accesorios que no correspondan al uniforme</span>
                      </li>
                    </ul>
                  </div>
                  <div className="bg-muted p-6 rounded-lg">
                    <h3 className="text-lg font-semibold mb-4">Comportamiento en el Aula</h3>
                    <ul className="space-y-2">
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Llegar puntualmente a clases</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Mantener un ambiente de respeto y orden</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Participar activamente en las actividades</span>
                      </li>
                    </ul>
                  </div>
                  <div className="bg-muted p-6 rounded-lg">
                    <h3 className="text-lg font-semibold mb-4">Uso de Instalaciones</h3>
                    <ul className="space-y-2">
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Cuidar y preservar los bienes de la institución</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Mantener limpios los espacios comunes</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Utilizar adecuadamente los recursos</span>
                      </li>
                    </ul>
                  </div>
                  <div className="bg-muted p-6 rounded-lg">
                    <h3 className="text-lg font-semibold mb-4">Relaciones Interpersonales</h3>
                    <ul className="space-y-2">
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Tratar con respeto a todos los miembros de la comunidad</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>No incurrir en actos de discriminación o bullying</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Resolver los conflictos de manera pacífica</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="procedimientos">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-primary" />
                  Procedimientos
                </CardTitle>
                <CardDescription>
                  Procedimientos para la resolución de conflictos y aplicación de medidas formativas
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <p className="text-muted-foreground">
                  Los procedimientos establecidos en el Manual de Convivencia buscan garantizar el debido proceso y la
                  aplicación de medidas formativas que contribuyan al crecimiento personal de los estudiantes.
                </p>

                <div className="mt-6">
                  <h3 className="text-lg font-semibold mb-4 text-primary">Clasificación de Faltas</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-white dark:bg-primary/5 p-4 rounded-lg border border-border">
                      <h4 className="font-semibold mb-2 text-primary">Faltas Leves</h4>
                      <p className="text-sm text-muted-foreground mb-2">
                        Aquellas que no afectan significativamente la convivencia escolar.
                      </p>
                      <p className="text-sm text-muted-foreground">
                        <strong>Procedimiento:</strong> Llamado de atención verbal, anotación en el observador, diálogo
                        formativo.
                      </p>
                    </div>
                    <div className="bg-white dark:bg-primary/5 p-4 rounded-lg border border-border">
                      <h4 className="font-semibold mb-2 text-primary">Faltas Graves</h4>
                      <p className="text-sm text-muted-foreground mb-2">
                        Aquellas que afectan la convivencia escolar o son reincidencias de faltas leves.
                      </p>
                      <p className="text-sm text-muted-foreground">
                        <strong>Procedimiento:</strong> Anotación en el observador, citación a padres, trabajo
                        pedagógico, suspensión de 1 a 3 días.
                      </p>
                    </div>
                    <div className="bg-white dark:bg-primary/5 p-4 rounded-lg border border-border">
                      <h4 className="font-semibold mb-2 text-primary">Faltas Muy Graves</h4>
                      <p className="text-sm text-muted-foreground mb-2">
                        Aquellas que afectan gravemente la convivencia escolar o la integridad de las personas.
                      </p>
                      <p className="text-sm text-muted-foreground">
                        <strong>Procedimiento:</strong> Remisión al Comité de Convivencia, suspensión de 3 a 5 días,
                        matrícula condicional.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="mt-8">
                  <h3 className="text-lg font-semibold mb-4 text-primary">Debido Proceso</h3>
                  <ol className="space-y-4">
                    <li className="flex items-start gap-4">
                      <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="font-semibold">1</span>
                      </div>
                      <div>
                        <h4 className="font-semibold">Conocimiento de la falta</h4>
                        <p className="text-muted-foreground">
                          Identificación y reporte de la situación por parte de cualquier miembro de la comunidad
                          educativa.
                        </p>
                      </div>
                    </li>
                    <li className="flex items-start gap-4">
                      <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="font-semibold">2</span>
                      </div>
                      <div>
                        <h4 className="font-semibold">Formulación de cargos</h4>
                        <p className="text-muted-foreground">
                          Comunicación formal al estudiante sobre la falta cometida y las posibles consecuencias.
                        </p>
                      </div>
                    </li>
                    <li className="flex items-start gap-4">
                      <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="font-semibold">3</span>
                      </div>
                      <div>
                        <h4 className="font-semibold">Presentación de descargos</h4>
                        <p className="text-muted-foreground">
                          Oportunidad para que el estudiante explique su versión de los hechos y presente pruebas.
                        </p>
                      </div>
                    </li>
                    <li className="flex items-start gap-4">
                      <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="font-semibold">4</span>
                      </div>
                      <div>
                        <h4 className="font-semibold">Análisis del caso</h4>
                        <p className="text-muted-foreground">
                          Evaluación de la situación, considerando los descargos y las pruebas presentadas.
                        </p>
                      </div>
                    </li>
                    <li className="flex items-start gap-4">
                      <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="font-semibold">5</span>
                      </div>
                      <div>
                        <h4 className="font-semibold">Decisión</h4>
                        <p className="text-muted-foreground">
                          Determinación de la responsabilidad y aplicación de medidas formativas o sanciones.
                        </p>
                      </div>
                    </li>
                    <li className="flex items-start gap-4">
                      <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="font-semibold">6</span>
                      </div>
                      <div>
                        <h4 className="font-semibold">Recursos</h4>
                        <p className="text-muted-foreground">
                          Posibilidad de presentar recursos de reposición o apelación frente a la decisión.
                        </p>
                      </div>
                    </li>
                    <li className="flex items-start gap-4">
                      <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="font-semibold">7</span>
                      </div>
                      <div>
                        <h4 className="font-semibold">Seguimiento</h4>
                        <p className="text-muted-foreground">
                          Monitoreo del cumplimiento de las medidas formativas y evaluación de su efectividad.
                        </p>
                      </div>
                    </li>
                  </ol>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex justify-center">
          <Button asChild>
            <Link href="/">Volver al inicio</Link>
          </Button>
        </div>
      </div>
    </main>
  )
}

