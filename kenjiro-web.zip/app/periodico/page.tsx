import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FileText, Newspaper, Download, Users } from "lucide-react"

export default function PeriodicoPage() {
  return (
    <main className="container py-12">
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-col items-center mb-10 text-center">
          <div className="relative w-24 h-24 rounded-full overflow-hidden border-4 border-accent mb-6 shadow-md">
            <Image
              src="/logo-inedjas.png"
              alt="Logo INEDJAS"
              fill
              className="object-contain p-2 rounded-full"
              priority
            />
          </div>
          <h1 className="text-4xl font-bold mb-4">Periódico Escolar</h1>
          <p className="text-xl text-muted-foreground max-w-3xl">
            INEDJAS Informa: Nuestro periódico escolar, un espacio para la expresión, la información y el pensamiento
            crítico
          </p>
        </div>

        <div className="bg-primary/5 p-8 rounded-xl mb-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-4 text-primary">Última Edición</h2>
              <p className="text-muted-foreground mb-4">
                Ya está disponible la edición de octubre 2023 de nuestro periódico escolar. En esta edición encontrarás
                artículos sobre los eventos recientes, entrevistas a docentes y estudiantes destacados, y mucho más.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button className="gap-2">
                  <Download className="h-4 w-4" /> Descargar PDF
                </Button>
                <Button variant="outline" className="gap-2">
                  <Newspaper className="h-4 w-4" /> Ver en línea
                </Button>
              </div>
            </div>
            <div className="relative h-[300px] rounded-lg overflow-hidden border-4 border-accent/20">
              <Image
                src="/placeholder.svg?height=300&width=400"
                alt="Portada del periódico escolar"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>

        <Tabs defaultValue="acerca" className="mb-12">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="acerca">Acerca del Periódico</TabsTrigger>
            <TabsTrigger value="ediciones">Ediciones Anteriores</TabsTrigger>
            <TabsTrigger value="equipo">Equipo Editorial</TabsTrigger>
          </TabsList>

          <TabsContent value="acerca">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Newspaper className="h-5 w-5 text-primary" />
                  Nuestro Periódico Escolar
                </CardTitle>
                <CardDescription>
                  Conoce más sobre el periódico escolar de la Institución Educativa Distrital Juan Acosta Solera
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <p className="text-muted-foreground">
                  El periódico escolar INEDJAS Informa es un proyecto pedagógico que busca fomentar la lectura, la
                  escritura y el pensamiento crítico en nuestros estudiantes, a la vez que sirve como medio de
                  comunicación para toda la comunidad educativa.
                </p>
                <p className="text-muted-foreground">
                  Fundado en 2012, nuestro periódico se publica mensualmente y cuenta con la participación de
                  estudiantes de diferentes grados, quienes bajo la orientación de docentes del área de Lengua
                  Castellana, se encargan de la redacción, edición, diseño y distribución del mismo.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                  <div className="bg-muted p-6 rounded-lg">
                    <h3 className="text-lg font-semibold mb-4">Objetivos</h3>
                    <ul className="space-y-2">
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Fomentar la lectura y la escritura en los estudiantes</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Desarrollar el pensamiento crítico y la capacidad de análisis</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Informar sobre eventos y actividades de la institución</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Promover la participación y el trabajo en equipo</span>
                      </li>
                    </ul>
                  </div>
                  <div className="bg-muted p-6 rounded-lg">
                    <h3 className="text-lg font-semibold mb-4">Secciones</h3>
                    <ul className="space-y-2">
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Editorial: Reflexiones sobre temas de actualidad</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Noticias: Eventos y actividades de la institución</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Entrevistas: A miembros destacados de la comunidad</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Cultura: Arte, literatura y expresiones culturales</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span className="h-2 w-2 rounded-full bg-primary"></span>
                        </span>
                        <span>Deportes: Resultados y eventos deportivos</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ediciones">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-primary" />
                  Ediciones Anteriores
                </CardTitle>
                <CardDescription>Accede a las ediciones anteriores de nuestro periódico escolar</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {[
                    { month: "Septiembre", year: "2023", image: "/placeholder.svg?height=200&width=150" },
                    { month: "Agosto", year: "2023", image: "/placeholder.svg?height=200&width=150" },
                    { month: "Julio", year: "2023", image: "/placeholder.svg?height=200&width=150" },
                    { month: "Junio", year: "2023", image: "/placeholder.svg?height=200&width=150" },
                    { month: "Mayo", year: "2023", image: "/placeholder.svg?height=200&width=150" },
                    { month: "Abril", year: "2023", image: "/placeholder.svg?height=200&width=150" },
                  ].map((edition, index) => (
                    <div
                      key={index}
                      className="bg-white dark:bg-primary/5 rounded-lg border border-border overflow-hidden"
                    >
                      <div className="relative h-[200px]">
                        <Image
                          src={edition.image || "/placeholder.svg"}
                          alt={`Edición ${edition.month} ${edition.year}`}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="p-4">
                        <h3 className="font-semibold mb-1">
                          Edición {edition.month} {edition.year}
                        </h3>
                        <div className="flex justify-between items-center mt-2">
                          <Button variant="outline" size="sm" className="gap-1">
                            <Newspaper className="h-3 w-3" /> Ver
                          </Button>
                          <Button variant="outline" size="sm" className="gap-1">
                            <Download className="h-3 w-3" /> PDF
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="equipo">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-primary" />
                  Equipo Editorial
                </CardTitle>
                <CardDescription>
                  Conoce a los estudiantes y docentes que hacen posible nuestro periódico escolar
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-8">
                  <h3 className="text-xl font-semibold mb-4 text-primary">Coordinación</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="bg-white dark:bg-primary/5 p-6 rounded-lg border border-border">
                      <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                        <Users className="h-8 w-8 text-primary" />
                      </div>
                      <h3 className="text-lg font-semibold text-center mb-1">Prof. María Rodríguez</h3>
                      <p className="text-primary text-sm text-center mb-3">Directora Editorial</p>
                      <p className="text-muted-foreground text-sm text-center">
                        Docente de Lengua Castellana y coordinadora del proyecto desde 2015.
                      </p>
                    </div>
                    <div className="bg-white dark:bg-primary/5 p-6 rounded-lg border border-border">
                      <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                        <Users className="h-8 w-8 text-primary" />
                      </div>
                      <h3 className="text-lg font-semibold text-center mb-1">Prof. Roberto Sánchez</h3>
                      <p className="text-primary text-sm text-center mb-3">Editor General</p>
                      <p className="text-muted-foreground text-sm text-center">
                        Docente de Ciencias Sociales, encargado de la revisión y edición de contenidos.
                      </p>
                    </div>
                    <div className="bg-white dark:bg-primary/5 p-6 rounded-lg border border-border">
                      <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                        <Users className="h-8 w-8 text-primary" />
                      </div>
                      <h3 className="text-lg font-semibold text-center mb-1">Prof. Ana Gómez</h3>
                      <p className="text-primary text-sm text-center mb-3">Asesora de Diseño</p>
                      <p className="text-muted-foreground text-sm text-center">
                        Docente de Artes, responsable del diseño y diagramación del periódico.
                      </p>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-xl font-semibold mb-4 text-primary">Equipo Estudiantil</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="bg-white dark:bg-primary/5 p-4 rounded-lg border border-border">
                      <h4 className="font-medium">Lucía Martínez</h4>
                      <div className="flex justify-between text-sm text-muted-foreground">
                        <span>11°</span>
                        <span>Editora en Jefe</span>
                      </div>
                    </div>
                    <div className="bg-white dark:bg-primary/5 p-4 rounded-lg border border-border">
                      <h4 className="font-medium">Mateo Hernández</h4>
                      <div className="flex justify-between text-sm text-muted-foreground">
                        <span>11°</span>
                        <span>Jefe de Redacción</span>
                      </div>
                    </div>
                    <div className="bg-white dark:bg-primary/5 p-4 rounded-lg border border-border">
                      <h4 className="font-medium">Isabella Díaz</h4>
                      <div className="flex justify-between text-sm text-muted-foreground">
                        <span>10°</span>
                        <span>Diseñadora</span>
                      </div>
                    </div>
                    <div className="bg-white dark:bg-primary/5 p-4 rounded-lg border border-border">
                      <h4 className="font-medium">Santiago López</h4>
                      <div className="flex justify-between text-sm text-muted-foreground">
                        <span>10°</span>
                        <span>Fotógrafo</span>
                      </div>
                    </div>
                    <div className="bg-white dark:bg-primary/5 p-4 rounded-lg border border-border">
                      <h4 className="font-medium">Valeria Torres</h4>
                      <div className="flex justify-between text-sm text-muted-foreground">
                        <span>9°</span>
                        <span>Reportera</span>
                      </div>
                    </div>
                    <div className="bg-white dark:bg-primary/5 p-4 rounded-lg border border-border">
                      <h4 className="font-medium">Alejandro Ramírez</h4>
                      <div className="flex justify-between text-sm text-muted-foreground">
                        <span>9°</span>
                        <span>Reportero</span>
                      </div>
                    </div>
                    <div className="bg-white dark:bg-primary/5 p-4 rounded-lg border border-border">
                      <h4 className="font-medium">Gabriela Morales</h4>
                      <div className="flex justify-between text-sm text-muted-foreground">
                        <span>8°</span>
                        <span>Redactora</span>
                      </div>
                    </div>
                    <div className="bg-white dark:bg-primary/5 p-4 rounded-lg border border-border">
                      <h4 className="font-medium">Daniel Vargas</h4>
                      <div className="flex justify-between text-sm text-muted-foreground">
                        <span>8°</span>
                        <span>Redactor</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-8 bg-muted p-6 rounded-lg">
                  <h3 className="text-xl font-semibold mb-4">¿Quieres formar parte del equipo?</h3>
                  <p className="mb-4">
                    Si eres estudiante de INEDJAS y te interesa participar en el periódico escolar, puedes inscribirte
                    en las convocatorias que se realizan al inicio de cada año escolar.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4">
                    <Button asChild>
                      <Link href="/contacto">Más información</Link>
                    </Button>
                    <Button variant="outline">Descargar formulario</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex justify-center">
          <Button asChild>
            <Link href="/">Volver al inicio</Link>
          </Button>
        </div>
      </div>
    </main>
  )
}

