import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { CalendarIcon, Clock, FileText, MapPin, Users } from "lucide-react"

export default function CalendarioPage() {
  return (
    <main className="container py-12">
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-col items-center mb-10 text-center">
          <div className="relative w-24 h-24 rounded-full overflow-hidden border-4 border-accent mb-6 shadow-md">
            <Image
              src="/logo-inedjas.png"
              alt="Logo INEDJAS"
              fill
              className="object-contain p-2 rounded-full"
              priority
            />
          </div>
          <h1 className="text-4xl font-bold mb-4">Calendario Escolar</h1>
          <p className="text-xl text-muted-foreground max-w-3xl">
            Mantente al día con todas las actividades, eventos y fechas importantes de nuestra institución
          </p>
        </div>

        <div className="bg-primary/5 p-8 rounded-xl mb-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-4 text-primary">Próximos Eventos</h2>
              <p className="text-muted-foreground mb-4">
                Consulta nuestro calendario escolar para no perderte ninguna actividad importante. Aquí encontrarás
                información sobre eventos académicos, culturales, deportivos y fechas administrativas.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button className="gap-2">
                  <CalendarIcon className="h-4 w-4" /> Descargar Calendario
                </Button>
                <Button variant="outline" className="gap-2">
                  <FileText className="h-4 w-4" /> Ver Cronograma Anual
                </Button>
              </div>
            </div>
            <div className="relative h-[300px] rounded-lg overflow-hidden border-4 border-accent/20">
              <Image
                src="/placeholder.svg?height=300&width=400"
                alt="Calendario Escolar"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </div>

        <Tabs defaultValue="eventos" className="mb-12">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="eventos">Eventos Próximos</TabsTrigger>
            <TabsTrigger value="academico">Calendario Académico</TabsTrigger>
            <TabsTrigger value="institucional">Eventos Institucionales</TabsTrigger>
          </TabsList>

          <TabsContent value="eventos">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CalendarIcon className="h-5 w-5 text-primary" />
                  Eventos Próximos
                </CardTitle>
                <CardDescription>Actividades y eventos programados para las próximas semanas</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <EventCard
                    title="Feria de Ciencias"
                    date="15 de noviembre, 2023"
                    time="9:00 AM - 3:00 PM"
                    location="Patio central"
                    description="Presentación de proyectos científicos desarrollados por estudiantes de todos los grados. Habrá premios para los mejores proyectos."
                    category="Académico"
                  />
                  <EventCard
                    title="Torneo Interclases de Fútbol"
                    date="18-22 de noviembre, 2023"
                    time="Durante los descansos"
                    location="Cancha deportiva"
                    description="Competencia deportiva entre los diferentes cursos. Categorías: 6°-7°, 8°-9° y 10°-11°."
                    category="Deportivo"
                  />
                  <EventCard
                    title="Reunión de Padres de Familia"
                    date="25 de noviembre, 2023"
                    time="8:00 AM - 12:00 PM"
                    location="Aulas de clase"
                    description="Entrega de informes académicos correspondientes al tercer período. Es importante la asistencia de todos los padres o acudientes."
                    category="Institucional"
                  />
                  <EventCard
                    title="Festival Cultural"
                    date="1 de diciembre, 2023"
                    time="1:00 PM - 5:00 PM"
                    location="Auditorio"
                    description="Presentaciones artísticas, musicales y teatrales a cargo de los estudiantes. Muestra de talentos y expresiones culturales."
                    category="Cultural"
                  />
                  <EventCard
                    title="Jornada de Orientación Profesional"
                    date="5 de diciembre, 2023"
                    time="10:00 AM - 12:00 PM"
                    location="Biblioteca"
                    description="Charlas informativas sobre opciones universitarias y profesionales para estudiantes de 10° y 11°. Participarán representantes de diferentes universidades."
                    category="Académico"
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="academico">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-primary" />
                  Calendario Académico
                </CardTitle>
                <CardDescription>Fechas importantes del año escolar 2023-2024</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-8">
                  <div>
                    <h3 className="text-lg font-semibold mb-4 text-primary">Primer Semestre</h3>
                    <div className="space-y-4">
                      <div className="flex items-start gap-4 p-4 bg-muted rounded-lg">
                        <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <CalendarIcon className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <h4 className="font-semibold">Inicio de clases</h4>
                          <p className="text-muted-foreground">15 de enero, 2024</p>
                          <p className="text-sm text-muted-foreground mt-1">
                            Inicio del año escolar para todos los estudiantes.
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start gap-4 p-4 bg-muted rounded-lg">
                        <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <CalendarIcon className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <h4 className="font-semibold">Evaluaciones primer período</h4>
                          <p className="text-muted-foreground">11-15 de marzo, 2024</p>
                          <p className="text-sm text-muted-foreground mt-1">
                            Evaluaciones correspondientes al primer período académico.
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start gap-4 p-4 bg-muted rounded-lg">
                        <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <CalendarIcon className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <h4 className="font-semibold">Entrega de informes</h4>
                          <p className="text-muted-foreground">23 de marzo, 2024</p>
                          <p className="text-sm text-muted-foreground mt-1">
                            Entrega de informes académicos del primer período a padres de familia.
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start gap-4 p-4 bg-muted rounded-lg">
                        <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <CalendarIcon className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <h4 className="font-semibold">Receso de Semana Santa</h4>
                          <p className="text-muted-foreground">25-29 de marzo, 2024</p>
                          <p className="text-sm text-muted-foreground mt-1">
                            Receso escolar correspondiente a la Semana Santa.
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start gap-4 p-4 bg-muted rounded-lg">
                        <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <CalendarIcon className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <h4 className="font-semibold">Finalización primer semestre</h4>
                          <p className="text-muted-foreground">14 de junio, 2024</p>
                          <p className="text-sm text-muted-foreground mt-1">
                            Finalización de actividades académicas del primer semestre.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold mb-4 text-primary">Segundo Semestre</h3>
                    <div className="space-y-4">
                      <div className="flex items-start gap-4 p-4 bg-muted rounded-lg">
                        <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <CalendarIcon className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <h4 className="font-semibold">Inicio segundo semestre</h4>
                          <p className="text-muted-foreground">8 de julio, 2024</p>
                          <p className="text-sm text-muted-foreground mt-1">
                            Reinicio de actividades académicas después de vacaciones de mitad de año.
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start gap-4 p-4 bg-muted rounded-lg">
                        <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <CalendarIcon className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <h4 className="font-semibold">Semana Cultural</h4>
                          <p className="text-muted-foreground">9-13 de septiembre, 2024</p>
                          <p className="text-sm text-muted-foreground mt-1">
                            Actividades culturales, artísticas y deportivas.
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start gap-4 p-4 bg-muted rounded-lg">
                        <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <CalendarIcon className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <h4 className="font-semibold">Evaluaciones finales</h4>
                          <p className="text-muted-foreground">11-15 de noviembre, 2024</p>
                          <p className="text-sm text-muted-foreground mt-1">
                            Evaluaciones correspondientes al último período académico.
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start gap-4 p-4 bg-muted rounded-lg">
                        <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <CalendarIcon className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <h4 className="font-semibold">Ceremonia de graduación</h4>
                          <p className="text-muted-foreground">29 de noviembre, 2024</p>
                          <p className="text-sm text-muted-foreground mt-1">
                            Ceremonia de graduación para estudiantes de 11° grado.
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start gap-4 p-4 bg-muted rounded-lg">
                        <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <CalendarIcon className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <h4 className="font-semibold">Finalización año escolar</h4>
                          <p className="text-muted-foreground">6 de diciembre, 2024</p>
                          <p className="text-sm text-muted-foreground mt-1">
                            Finalización de actividades académicas del año escolar.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="institucional">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-primary" />
                  Eventos Institucionales
                </CardTitle>
                <CardDescription>Eventos y celebraciones importantes de nuestra institución</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white dark:bg-primary/5 p-6 rounded-lg border border-border">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                        <CalendarIcon className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold">Aniversario Institucional</h3>
                        <p className="text-sm text-muted-foreground">15 de marzo, 2024</p>
                      </div>
                    </div>
                    <p className="text-muted-foreground">
                      Celebración del aniversario de fundación de nuestra institución. Habrá acto cultural,
                      reconocimientos y actividades especiales.
                    </p>
                  </div>
                  <div className="bg-white dark:bg-primary/5 p-6 rounded-lg border border-border">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                        <CalendarIcon className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold">Día del Maestro</h3>
                        <p className="text-sm text-muted-foreground">15 de mayo, 2024</p>
                      </div>
                    </div>
                    <p className="text-muted-foreground">
                      Homenaje a nuestros docentes por su dedicación y compromiso con la educación. Acto especial
                      organizado por estudiantes.
                    </p>
                  </div>
                  <div className="bg-white dark:bg-primary/5 p-6 rounded-lg border border-border">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                        <CalendarIcon className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold">Semana Cultural</h3>
                        <p className="text-sm text-muted-foreground">9-13 de septiembre, 2024</p>
                      </div>
                    </div>
                    <p className="text-muted-foreground">
                      Semana dedicada a actividades culturales, artísticas, deportivas y académicas. Participación de
                      toda la comunidad educativa.
                    </p>
                  </div>
                  <div className="bg-white dark:bg-primary/5 p-6 rounded-lg border border-border">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                        <CalendarIcon className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold">Día de la Familia</h3>
                        <p className="text-sm text-muted-foreground">12 de octubre, 2024</p>
                      </div>
                    </div>
                    <p className="text-muted-foreground">
                      Jornada de integración con las familias de nuestros estudiantes. Actividades recreativas,
                      culturales y deportivas.
                    </p>
                  </div>
                  <div className="bg-white dark:bg-primary/5 p-6 rounded-lg border border-border">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                        <CalendarIcon className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold">Ceremonia de Graduación</h3>
                        <p className="text-sm text-muted-foreground">29 de noviembre, 2024</p>
                      </div>
                    </div>
                    <p className="text-muted-foreground">
                      Acto solemne de graduación de los estudiantes de 11° grado. Entrega de diplomas y reconocimientos.
                    </p>
                  </div>
                  <div className="bg-white dark:bg-primary/5 p-6 rounded-lg border border-border">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                        <CalendarIcon className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold">Clausura del Año Escolar</h3>
                        <p className="text-sm text-muted-foreground">6 de diciembre, 2024</p>
                      </div>
                    </div>
                    <p className="text-muted-foreground">
                      Acto de clausura del año escolar. Entrega de informes finales, reconocimientos y actividades de
                      cierre.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex justify-center">
          <Button asChild>
            <Link href="/">Volver al inicio</Link>
          </Button>
        </div>
      </div>
    </main>
  )
}

function EventCard({
  title,
  date,
  time,
  location,
  description,
  category,
}: {
  title: string
  date: string
  time: string
  location: string
  description: string
  category: string
}) {
  return (
    <div className="flex flex-col md:flex-row gap-4 p-4 bg-white dark:bg-primary/5 rounded-lg border border-border">
      <div className="md:w-1/4">
        <Badge className="mb-2">{category}</Badge>
        <h3 className="text-lg font-semibold mb-1">{title}</h3>
        <p className="text-sm text-muted-foreground flex items-center gap-1 mb-1">
          <CalendarIcon className="h-3 w-3" /> {date}
        </p>
        <p className="text-sm text-muted-foreground flex items-center gap-1 mb-1">
          <Clock className="h-3 w-3" /> {time}
        </p>
        <p className="text-sm text-muted-foreground flex items-center gap-1">
          <MapPin className="h-3 w-3" /> {location}
        </p>
      </div>
      <div className="md:w-3/4">
        <p className="text-muted-foreground">{description}</p>
      </div>
    </div>
  )
}

