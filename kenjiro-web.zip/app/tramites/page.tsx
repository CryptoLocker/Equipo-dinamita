import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Download, FileText, Clock, CheckCircle, AlertCircle } from "lucide-react"

export default function TramitesPage() {
  return (
    <main className="container py-12">
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-col items-center mb-10 text-center">
          <div className="relative w-24 h-24 rounded-full overflow-hidden border-4 border-accent mb-6 shadow-md">
            <Image
              src="/logo-inedjas.png"
              alt="Logo INEDJAS"
              fill
              className="object-contain p-2 rounded-full"
              priority
            />
          </div>
          <h1 className="text-4xl font-bold mb-4">Trámites</h1>
          <p className="text-xl text-muted-foreground max-w-3xl">
            Información sobre los diferentes trámites administrativos y académicos que puedes realizar en nuestra
            institución
          </p>
        </div>

        <div className="bg-yellow-50 dark:bg-yellow-900/20 p-6 rounded-lg mb-8 border border-yellow-200 dark:border-yellow-800">
          <div className="flex items-start gap-3">
            <AlertCircle className="h-6 w-6 text-yellow-600 dark:text-yellow-400 flex-shrink-0 mt-0.5" />
            <div>
              <h2 className="text-xl font-bold text-yellow-800 dark:text-yellow-300 mb-2">
                Inscripciones y Matrículas
              </h2>
              <p className="text-yellow-700 dark:text-yellow-400">
                Las inscripciones y matrículas se realizan de manera <strong>presencial</strong> en la secretaría de la
                institución. Para iniciar el proceso, debe acercarse a nuestras instalaciones en el horario de atención
                establecido con los documentos requeridos. Para más información, puede contactarnos por teléfono al
                (+57) 300 123 4567.
              </p>
            </div>
          </div>
        </div>

        <Tabs defaultValue="certificados" className="mb-12">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="certificados">Certificados</TabsTrigger>
            <TabsTrigger value="constancias">Constancias</TabsTrigger>
            <TabsTrigger value="traslados">Traslados</TabsTrigger>
          </TabsList>

          <TabsContent value="certificados">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-primary" />
                  Certificados
                </CardTitle>
                <CardDescription>
                  Información sobre los certificados que puedes solicitar en nuestra institución
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <p className="text-muted-foreground">
                  Los certificados son documentos oficiales que acreditan información académica de los estudiantes.
                  Nuestra institución emite diferentes tipos de certificados según las necesidades de los solicitantes.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                  <TramiteCard
                    title="Certificado de Notas"
                    description="Documento que certifica las calificaciones obtenidas por el estudiante en un período académico específico."
                    requirements={[
                      "Solicitud por escrito o formulario de solicitud",
                      "Documento de identidad del estudiante",
                      "Documento de identidad del solicitante (si es diferente al estudiante)",
                      "Pago de derechos de certificación",
                    ]}
                    time="3 días hábiles"
                    cost="$10.000"
                  />
                  <TramiteCard
                    title="Certificado de Estudios"
                    description="Documento que certifica que el estudiante cursó o está cursando determinado grado en la institución."
                    requirements={[
                      "Solicitud por escrito o formulario de solicitud",
                      "Documento de identidad del estudiante",
                      "Documento de identidad del solicitante (si es diferente al estudiante)",
                      "Pago de derechos de certificación",
                    ]}
                    time="3 días hábiles"
                    cost="$10.000"
                  />
                  <TramiteCard
                    title="Certificado de Comportamiento"
                    description="Documento que certifica el comportamiento del estudiante durante su permanencia en la institución."
                    requirements={[
                      "Solicitud por escrito o formulario de solicitud",
                      "Documento de identidad del estudiante",
                      "Documento de identidad del solicitante (si es diferente al estudiante)",
                      "Pago de derechos de certificación",
                    ]}
                    time="3 días hábiles"
                    cost="$10.000"
                  />
                  <TramiteCard
                    title="Certificado de Graduación"
                    description="Documento que certifica que el estudiante se graduó de la institución en determinada fecha."
                    requirements={[
                      "Solicitud por escrito o formulario de solicitud",
                      "Documento de identidad del estudiante",
                      "Documento de identidad del solicitante (si es diferente al estudiante)",
                      "Pago de derechos de certificación",
                    ]}
                    time="3 días hábiles"
                    cost="$10.000"
                  />
                </div>

                <div className="bg-muted p-6 rounded-lg mt-6">
                  <h3 className="text-lg font-semibold mb-4">Procedimiento para solicitar certificados</h3>
                  <ol className="space-y-2">
                    <li className="flex items-start gap-2">
                      <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span>1</span>
                      </span>
                      <span>Descargar y diligenciar el formulario de solicitud</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span>2</span>
                      </span>
                      <span>Realizar el pago de los derechos de certificación</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span>3</span>
                      </span>
                      <span>Entregar la solicitud y el comprobante de pago en la secretaría académica</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span>4</span>
                      </span>
                      <span>Reclamar el certificado en la fecha indicada presentando el documento de identidad</span>
                    </li>
                  </ol>
                  <div className="flex justify-center mt-4">
                    <Button className="gap-2">
                      <Download className="h-4 w-4" /> Descargar Formulario
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="constancias">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-primary" />
                  Constancias
                </CardTitle>
                <CardDescription>
                  Información sobre las constancias que puedes solicitar en nuestra institución
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <p className="text-muted-foreground">
                  Las constancias son documentos que certifican información específica sobre los estudiantes, como su
                  vinculación a la institución, horarios, entre otros.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                  <TramiteCard
                    title="Constancia de Estudio"
                    description="Documento que certifica que el estudiante está matriculado en la institución en el año escolar actual."
                    requirements={[
                      "Solicitud por escrito o formulario de solicitud",
                      "Documento de identidad del estudiante",
                      "Documento de identidad del solicitante (si es diferente al estudiante)",
                      "Pago de derechos de constancia",
                    ]}
                    time="1 día hábil"
                    cost="$5.000"
                  />
                  <TramiteCard
                    title="Constancia de Horario"
                    description="Documento que certifica el horario de clases del estudiante en el período académico actual."
                    requirements={[
                      "Solicitud por escrito o formulario de solicitud",
                      "Documento de identidad del estudiante",
                      "Documento de identidad del solicitante (si es diferente al estudiante)",
                      "Pago de derechos de constancia",
                    ]}
                    time="1 día hábil"
                    cost="$5.000"
                  />
                  <TramiteCard
                    title="Constancia de Asistencia"
                    description="Documento que certifica la asistencia del estudiante a la institución en una fecha específica."
                    requirements={[
                      "Solicitud por escrito o formulario de solicitud",
                      "Documento de identidad del estudiante",
                      "Documento de identidad del solicitante (si es diferente al estudiante)",
                      "Pago de derechos de constancia",
                    ]}
                    time="1 día hábil"
                    cost="$5.000"
                  />
                  <TramiteCard
                    title="Constancia para EPS"
                    description="Documento que certifica que el estudiante está matriculado en la institución, para trámites ante la EPS."
                    requirements={[
                      "Solicitud por escrito o formulario de solicitud",
                      "Documento de identidad del estudiante",
                      "Documento de identidad del solicitante (si es diferente al estudiante)",
                      "Pago de derechos de constancia",
                    ]}
                    time="1 día hábil"
                    cost="$5.000"
                  />
                </div>

                <div className="bg-muted p-6 rounded-lg mt-6">
                  <h3 className="text-lg font-semibold mb-4">Procedimiento para solicitar constancias</h3>
                  <ol className="space-y-2">
                    <li className="flex items-start gap-2">
                      <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span>1</span>
                      </span>
                      <span>Descargar y diligenciar el formulario de solicitud</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span>2</span>
                      </span>
                      <span>Realizar el pago de los derechos de constancia</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span>3</span>
                      </span>
                      <span>Entregar la solicitud y el comprobante de pago en la secretaría académica</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span>4</span>
                      </span>
                      <span>Reclamar la constancia en la fecha indicada presentando el documento de identidad</span>
                    </li>
                  </ol>
                  <div className="flex justify-center mt-4">
                    <Button className="gap-2">
                      <Download className="h-4 w-4" /> Descargar Formulario
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="traslados">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-primary" />
                  Traslados
                </CardTitle>
                <CardDescription>
                  Información sobre el proceso de traslado desde y hacia nuestra institución
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <p className="text-muted-foreground">
                  El traslado es el proceso mediante el cual un estudiante cambia de institución educativa. A
                  continuación, encontrarás información sobre los traslados desde y hacia nuestra institución.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                  <div className="bg-white dark:bg-primary/5 p-6 rounded-lg border border-border">
                    <h3 className="text-lg font-semibold mb-4">Traslado desde otra institución</h3>
                    <p className="text-muted-foreground mb-4">
                      Para los estudiantes que desean trasladarse a nuestra institución, el proceso incluye los
                      siguientes pasos:
                    </p>
                    <ol className="space-y-2">
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span>1</span>
                        </span>
                        <span>Verificación de disponibilidad de cupo</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span>2</span>
                        </span>
                        <span>Entrevista con coordinación académica</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span>3</span>
                        </span>
                        <span>Presentación de documentación requerida</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span>4</span>
                        </span>
                        <span>Proceso de matrícula</span>
                      </li>
                    </ol>
                    <div className="mt-4">
                      <h4 className="font-semibold mb-2">Documentos requeridos:</h4>
                      <ul className="space-y-1 text-muted-foreground">
                        <li>• Certificado de notas del período cursado</li>
                        <li>• Paz y salvo de la institución de origen</li>
                        <li>• Certificado de comportamiento</li>
                        <li>• Documentos de identidad del estudiante y acudientes</li>
                        <li>• Certificado de afiliación a EPS</li>
                      </ul>
                    </div>
                  </div>
                  <div className="bg-white dark:bg-primary/5 p-6 rounded-lg border border-border">
                    <h3 className="text-lg font-semibold mb-4">Traslado hacia otra institución</h3>
                    <p className="text-muted-foreground mb-4">
                      Para los estudiantes que desean trasladarse desde nuestra institución hacia otra, el proceso
                      incluye los siguientes pasos:
                    </p>
                    <ol className="space-y-2">
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span>1</span>
                        </span>
                        <span>Solicitud de traslado por parte del acudiente</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span>2</span>
                        </span>
                        <span>Verificación de paz y salvo</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span>3</span>
                        </span>
                        <span>Emisión de certificados y documentación</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                          <span>4</span>
                        </span>
                        <span>Cancelación de matrícula</span>
                      </li>
                    </ol>
                    <div className="mt-4">
                      <h4 className="font-semibold mb-2">Documentos entregados:</h4>
                      <ul className="space-y-1 text-muted-foreground">
                        <li>• Certificado de notas del período cursado</li>
                        <li>• Paz y salvo institucional</li>
                        <li>• Certificado de comportamiento</li>
                        <li>• Documentos originales del estudiante</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="bg-muted p-6 rounded-lg mt-6">
                  <h3 className="text-lg font-semibold mb-4">Consideraciones importantes</h3>
                  <ul className="space-y-2">
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span>Los traslados están sujetos a disponibilidad de cupos.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span>El proceso de traslado puede tomar hasta 5 días hábiles.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span>Los traslados durante el año escolar deben ser justificados.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span>El estudiante debe estar al día con sus obligaciones académicas y financieras.</span>
                    </li>
                  </ul>
                  <div className="flex justify-center mt-4">
                    <Button className="gap-2">
                      <Download className="h-4 w-4" /> Descargar Formulario de Traslado
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="bg-primary/5 rounded-lg p-6 mb-8">
          <h2 className="text-2xl font-bold mb-4">¿Necesitas ayuda?</h2>
          <p className="mb-4">
            Si tienes dudas sobre algún trámite, puedes contactarnos a través de los siguientes medios:
          </p>
          <div className="space-y-2">
            <p>
              <strong>Teléfono:</strong> (+57) 300 123 4567
            </p>
            <p>
              <strong>Correo electrónico:</strong> tramites@inedjas.edu.co
            </p>
            <p>
              <strong>Horario de atención:</strong> Lunes a viernes de 8:00 AM a 3:00 PM
            </p>
          </div>
        </div>

        <div className="flex justify-center">
          <Button asChild>
            <Link href="/">Volver al inicio</Link>
          </Button>
        </div>
      </div>
    </main>
  )
}

function TramiteCard({
  title,
  description,
  requirements,
  time,
  cost,
}: {
  title: string
  description: string
  requirements: string[]
  time: string
  cost: string
}) {
  return (
    <div className="bg-white dark:bg-primary/5 p-6 rounded-lg border border-border">
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <p className="text-muted-foreground mb-4">{description}</p>
      <div className="space-y-4">
        <div>
          <h4 className="font-semibold text-sm mb-1">Requisitos:</h4>
          <ul className="space-y-1">
            {requirements.map((req, index) => (
              <li key={index} className="text-sm text-muted-foreground flex items-start gap-2">
                <span className="h-4 w-4 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="h-1.5 w-1.5 rounded-full bg-primary"></span>
                </span>
                <span>{req}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="flex justify-between">
          <div>
            <h4 className="font-semibold text-sm mb-1">Tiempo de entrega:</h4>
            <p className="text-sm text-muted-foreground flex items-center gap-1">
              <Clock className="h-3 w-3" /> {time}
            </p>
          </div>
          <div>
            <h4 className="font-semibold text-sm mb-1">Costo:</h4>
            <p className="text-sm text-muted-foreground">{cost}</p>
          </div>
        </div>
      </div>
    </div>
  )
}

