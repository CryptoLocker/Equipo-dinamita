import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Award, BookOpen, Calendar, Clock, FileText, GraduationCap, History, MapPin, Medal, Users } from "lucide-react"

export default function AcercaPage() {
  return (
    <main className="container py-12">
      <div className="max-w-4xl mx-auto">
        <div className="flex flex-col items-center mb-10 text-center">
          <div className="relative w-32 h-32 rounded-full overflow-hidden border-4 border-accent mb-6 shadow-md">
            <Image
              src="/logo-inedjas.png"
              alt="Logo INEDJAS"
              fill
              className="object-contain p-2 rounded-full"
              priority
            />
          </div>
          <h1 className="text-4xl font-bold mb-4">Institución Educativa Distrital Juan Acosta Solera</h1>
          <p className="text-xl text-muted-foreground">Formando líderes para el futuro con educación de calidad</p>
        </div>

        <Tabs defaultValue="historia" className="mb-12">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="historia">Historia</TabsTrigger>
            <TabsTrigger value="mision-vision">Misión y Visión</TabsTrigger>
            <TabsTrigger value="valores">Valores</TabsTrigger>
            <TabsTrigger value="instalaciones">Instalaciones</TabsTrigger>
          </TabsList>

          <TabsContent value="historia">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <History className="h-5 w-5 text-primary" />
                  Nuestra Historia
                </CardTitle>
                <CardDescription>Conoce los orígenes y evolución de nuestra institución educativa</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <p>
                  La Institución Educativa Distrital Juan Acosta Solera fue fundada en 1985 con el objetivo de brindar
                  educación de calidad a la comunidad de Barranquilla. Desde sus inicios, la institución se ha
                  caracterizado por su compromiso con la excelencia académica y la formación integral de sus
                  estudiantes.
                </p>
                <p>
                  A lo largo de los años, nuestra institución ha crecido y evolucionado, adaptándose a los cambios y
                  desafíos del sistema educativo colombiano. Hemos implementado innovaciones pedagógicas, mejorado
                  nuestras instalaciones y ampliado nuestra oferta educativa para responder a las necesidades de la
                  comunidad.
                </p>
                <p>
                  Hoy en día, la Institución Educativa Distrital Juan Acosta Solera es reconocida como un referente
                  educativo en la región, destacándose por sus logros académicos, deportivos y culturales. Nuestros
                  egresados han alcanzado importantes metas profesionales y personales, contribuyendo positivamente a la
                  sociedad.
                </p>
                <div className="mt-6">
                  <h3 className="text-lg font-semibold mb-2">Hitos Importantes</h3>
                  <ul className="space-y-2">
                    <li className="flex items-start gap-2">
                      <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="h-2 w-2 rounded-full bg-primary"></span>
                      </span>
                      <span>
                        <strong>1985:</strong> Fundación de la institución
                      </span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="h-2 w-2 rounded-full bg-primary"></span>
                      </span>
                      <span>
                        <strong>1995:</strong> Ampliación de instalaciones y apertura de secundaria
                      </span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="h-2 w-2 rounded-full bg-primary"></span>
                      </span>
                      <span>
                        <strong>2005:</strong> Reconocimiento como Institución Educativa Distrital
                      </span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="h-2 w-2 rounded-full bg-primary"></span>
                      </span>
                      <span>
                        <strong>2015:</strong> Implementación de nuevas tecnologías y metodologías educativas
                      </span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="h-2 w-2 rounded-full bg-primary"></span>
                      </span>
                      <span>
                        <strong>2020:</strong> Adaptación a la educación virtual y fortalecimiento de la plataforma
                        académica
                      </span>
                    </li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="mision-vision">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5 text-primary" />
                  Misión y Visión
                </CardTitle>
                <CardDescription>Nuestro propósito y proyección para el futuro</CardDescription>
              </CardHeader>
              <CardContent className="space-y-8">
                <div>
                  <h3 className="text-xl font-semibold mb-4 text-primary">Nuestra Misión</h3>
                  <p className="text-muted-foreground">
                    Formar integralmente a niños, niñas y jóvenes con altos estándares académicos, valores éticos y
                    morales, capacidad crítica y compromiso social, preparándolos para enfrentar los retos del mundo
                    contemporáneo y contribuir positivamente a la transformación de su entorno.
                  </p>
                  <p className="text-muted-foreground mt-4">
                    Nos comprometemos a brindar una educación de calidad que promueva el desarrollo de competencias
                    académicas, habilidades sociales y valores humanos, en un ambiente de respeto, inclusión y
                    participación activa de toda la comunidad educativa.
                  </p>
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-4 text-accent-foreground">Nuestra Visión</h3>
                  <p className="text-muted-foreground">
                    Para el año 2030, la Institución Educativa Distrital Juan Acosta Solera será reconocida a nivel
                    regional y nacional como un referente de excelencia educativa, innovación pedagógica y formación en
                    valores, destacándose por el alto desempeño académico de sus estudiantes y su impacto positivo en la
                    comunidad.
                  </p>
                  <p className="text-muted-foreground mt-4">
                    Aspiramos a ser una institución líder en la implementación de prácticas pedagógicas innovadoras, que
                    responda a las necesidades y desafíos del siglo XXI, formando ciudadanos competentes, éticos y
                    comprometidos con el desarrollo sostenible de su entorno.
                  </p>
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-4 text-secondary-foreground">Nuestro Lema</h3>
                  <div className="flex justify-center">
                    <div className="bg-secondary/10 px-8 py-4 rounded-lg inline-block">
                      <p className="text-xl font-medium">"Actitud, Liderazgo y Conocimiento"</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="valores">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5 text-primary" />
                  Valores Institucionales
                </CardTitle>
                <CardDescription>Principios que guían nuestra labor educativa</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white dark:bg-primary/5 p-6 rounded-lg border border-border">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <span className="text-xl font-bold text-primary">A</span>
                      </div>
                      <h3 className="text-lg font-semibold">Actitud</h3>
                    </div>
                    <p className="text-muted-foreground">
                      Promovemos una actitud positiva, proactiva y resiliente ante los desafíos, fomentando la
                      disposición para aprender, crecer y superar obstáculos con determinación y optimismo.
                    </p>
                  </div>
                  <div className="bg-white dark:bg-accent/5 p-6 rounded-lg border border-border">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="h-10 w-10 rounded-full bg-accent/10 flex items-center justify-center">
                        <span className="text-xl font-bold text-accent-foreground">L</span>
                      </div>
                      <h3 className="text-lg font-semibold">Liderazgo</h3>
                    </div>
                    <p className="text-muted-foreground">
                      Cultivamos el liderazgo en nuestros estudiantes, incentivándolos a tomar iniciativas, influir
                      positivamente en su entorno y desarrollar habilidades para guiar y trabajar en equipo con
                      responsabilidad y visión.
                    </p>
                  </div>
                  <div className="bg-white dark:bg-secondary/5 p-6 rounded-lg border border-border">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="h-10 w-10 rounded-full bg-secondary/10 flex items-center justify-center">
                        <span className="text-xl font-bold text-secondary-foreground">C</span>
                      </div>
                      <h3 className="text-lg font-semibold">Conocimiento</h3>
                    </div>
                    <p className="text-muted-foreground">
                      Valoramos la búsqueda constante del conocimiento, el pensamiento crítico y la curiosidad
                      intelectual, proporcionando las herramientas necesarias para que nuestros estudiantes sean
                      aprendices autónomos y permanentes.
                    </p>
                  </div>
                  <div className="bg-white dark:bg-primary/5 p-6 rounded-lg border border-border">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <span className="text-xl font-bold text-primary">R</span>
                      </div>
                      <h3 className="text-lg font-semibold">Respeto</h3>
                    </div>
                    <p className="text-muted-foreground">
                      Fomentamos el respeto hacia uno mismo, hacia los demás y hacia el entorno, reconociendo la
                      dignidad y los derechos de todas las personas, así como la importancia del cuidado del medio
                      ambiente.
                    </p>
                  </div>
                  <div className="bg-white dark:bg-accent/5 p-6 rounded-lg border border-border">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="h-10 w-10 rounded-full bg-accent/10 flex items-center justify-center">
                        <span className="text-xl font-bold text-accent-foreground">R</span>
                      </div>
                      <h3 className="text-lg font-semibold">Responsabilidad</h3>
                    </div>
                    <p className="text-muted-foreground">
                      Inculcamos el sentido de responsabilidad personal y social, promoviendo la conciencia de las
                      consecuencias de nuestras acciones y decisiones, así como el compromiso con el bienestar
                      colectivo.
                    </p>
                  </div>
                  <div className="bg-white dark:bg-secondary/5 p-6 rounded-lg border border-border">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="h-10 w-10 rounded-full bg-secondary/10 flex items-center justify-center">
                        <span className="text-xl font-bold text-secondary-foreground">S</span>
                      </div>
                      <h3 className="text-lg font-semibold">Solidaridad</h3>
                    </div>
                    <p className="text-muted-foreground">
                      Promovemos la solidaridad como valor fundamental, incentivando la empatía, la cooperación y el
                      apoyo mutuo entre los miembros de nuestra comunidad educativa y hacia la sociedad en general.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="instalaciones">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-primary" />
                  Nuestras Instalaciones
                </CardTitle>
                <CardDescription>Espacios diseñados para el aprendizaje y desarrollo integral</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <p>
                  La Institución Educativa Distrital Juan Acosta Solera cuenta con modernas instalaciones diseñadas para
                  proporcionar un ambiente óptimo de aprendizaje y desarrollo integral para nuestros estudiantes.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-muted/50 p-4 rounded-lg">
                    <h3 className="font-semibold mb-2 flex items-center gap-2">
                      <GraduationCap className="h-5 w-5 text-primary" />
                      Áreas Académicas
                    </h3>
                    <ul className="space-y-1 text-muted-foreground">
                      <li>• 30 aulas de clase equipadas con tecnología educativa</li>
                      <li>• 3 laboratorios de ciencias (física, química y biología)</li>
                      <li>• 2 salas de informática con equipos de última generación</li>
                      <li>• Biblioteca con más de 5,000 volúmenes</li>
                      <li>• Sala de audiovisuales</li>
                      <li>• Aula múltiple para eventos académicos</li>
                    </ul>
                  </div>
                  <div className="bg-muted/50 p-4 rounded-lg">
                    <h3 className="font-semibold mb-2 flex items-center gap-2">
                      <Medal className="h-5 w-5 text-primary" />
                      Áreas Deportivas
                    </h3>
                    <ul className="space-y-1 text-muted-foreground">
                      <li>• Cancha multideportiva cubierta</li>
                      <li>• Campo de fútbol</li>
                      <li>• Canchas de baloncesto y voleibol</li>
                      <li>• Pista de atletismo</li>
                      <li>• Gimnasio equipado</li>
                      <li>• Vestuarios y duchas</li>
                    </ul>
                  </div>
                  <div className="bg-muted/50 p-4 rounded-lg">
                    <h3 className="font-semibold mb-2 flex items-center gap-2">
                      <Users className="h-5 w-5 text-primary" />
                      Áreas Administrativas y de Servicios
                    </h3>
                    <ul className="space-y-1 text-muted-foreground">
                      <li>• Oficinas administrativas</li>
                      <li>• Sala de profesores</li>
                      <li>• Departamento de orientación escolar</li>
                      <li>• Enfermería</li>
                      <li>• Cafetería y comedor escolar</li>
                      <li>• Zonas de descanso y recreación</li>
                    </ul>
                  </div>
                  <div className="bg-muted/50 p-4 rounded-lg">
                    <h3 className="font-semibold mb-2 flex items-center gap-2">
                      <FileText className="h-5 w-5 text-primary" />
                      Áreas Culturales
                    </h3>
                    <ul className="space-y-1 text-muted-foreground">
                      <li>• Auditorio con capacidad para 300 personas</li>
                      <li>• Sala de música</li>
                      <li>• Taller de artes plásticas</li>
                      <li>• Estudio de radio escolar</li>
                      <li>• Sala de danza y expresión corporal</li>
                      <li>• Espacios para clubes y actividades extracurriculares</li>
                    </ul>
                  </div>
                </div>
                <div className="mt-6">
                  <h3 className="text-lg font-semibold mb-4">Horario de Atención</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-white dark:bg-primary/5 p-4 rounded-lg border border-border">
                      <h4 className="font-medium mb-2 flex items-center gap-2">
                        <Clock className="h-4 w-4 text-primary" />
                        Jornada Académica
                      </h4>
                      <ul className="space-y-1 text-muted-foreground">
                        <li>• Preescolar: 7:00 AM - 12:00 PM</li>
                        <li>• Primaria: 6:45 AM - 12:15 PM</li>
                        <li>• Secundaria y Media: 6:30 AM - 12:30 PM</li>
                        <li>• Jornada Complementaria: 2:00 PM - 5:00 PM</li>
                      </ul>
                    </div>
                    <div className="bg-white dark:bg-primary/5 p-4 rounded-lg border border-border">
                      <h4 className="font-medium mb-2 flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-primary" />
                        Atención Administrativa
                      </h4>
                      <ul className="space-y-1 text-muted-foreground">
                        <li>• Lunes a Viernes: 7:00 AM - 4:00 PM</li>
                        <li>• Sábados: 8:00 AM - 12:00 PM</li>
                        <li>• Secretaría Académica: 7:30 AM - 3:30 PM</li>
                        <li>• Atención a Padres: Previa cita</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex justify-center mt-8">
          <Button asChild>
            <Link href="/contacto">Contactar</Link>
          </Button>
        </div>
      </div>
    </main>
  )
}

