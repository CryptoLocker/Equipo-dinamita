import type React from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, FileText, Newspaper, Radio, Users } from "lucide-react"
import HeroSection from "@/components/hero-section"
import NewsSection from "@/components/news-section"
import FeaturesSection from "@/components/features-section"
import VirtualAssistant from "@/components/virtual-assistant"

export default function HomePage() {
  return (
    <main className="min-h-screen">
      {/* Hero Section */}
      <HeroSection />

      {/* Quick Access Section */}
      <section className="py-12 bg-muted/50">
        <div className="container">
          <h2 className="text-3xl font-bold text-center mb-8">Acceso Rápido</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            <QuickAccessCard href="/inscripciones" icon={<Users className="h-8 w-8" />} title="Inscripciones" />
            <QuickAccessCard href="/plataforma" icon={<FileText className="h-8 w-8" />} title="Plataforma Académica" />
            <QuickAccessCard
              href="/convivencia"
              icon={<FileText className="h-8 w-8" />}
              title="Manual de Convivencia"
            />
            <QuickAccessCard href="/emisora" icon={<Radio className="h-8 w-8" />} title="Emisora Escolar" />
            <QuickAccessCard href="/periodico" icon={<Newspaper className="h-8 w-8" />} title="Periódico Escolar" />
            <QuickAccessCard href="/calendario" icon={<Calendar className="h-8 w-8" />} title="Calendario" />
          </div>
        </div>
      </section>

      {/* News Section */}
      <NewsSection />

      {/* Features Section */}
      <FeaturesSection />

      {/* Office Hours Section */}
      <section className="py-12 bg-primary/5">
        <div className="container">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="md:w-1/2">
              <h2 className="text-3xl font-bold mb-4">Horario de Atención</h2>
              <p className="text-muted-foreground mb-6">
                Estamos disponibles para atender sus consultas y solicitudes en los siguientes horarios:
              </p>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  <span>Lunes a Viernes: 7:00 AM - 4:00 PM</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  <span>Sábados: 8:00 AM - 12:00 PM</span>
                </div>
              </div>
              <Button asChild className="mt-6">
                <Link href="/contacto">Contactar</Link>
              </Button>
            </div>
            <div className="md:w-1/2">
              <div className="bg-card rounded-lg shadow-lg p-6">
                <h3 className="text-xl font-semibold mb-4">Trámites Frecuentes</h3>
                <ul className="space-y-2">
                  <li>
                    <Link
                      href="/tramites/certificados"
                      className="text-primary hover:underline flex items-center gap-2"
                    >
                      <span className="h-1.5 w-1.5 rounded-full bg-primary"></span>
                      Solicitud de certificados
                    </Link>
                  </li>
                  <li>
                    <Link href="/tramites/constancias" className="text-primary hover:underline flex items-center gap-2">
                      <span className="h-1.5 w-1.5 rounded-full bg-primary"></span>
                      Constancias de estudio
                    </Link>
                  </li>
                  <li>
                    <Link href="/tramites/matricula" className="text-primary hover:underline flex items-center gap-2">
                      <span className="h-1.5 w-1.5 rounded-full bg-primary"></span>
                      Proceso de matrícula
                    </Link>
                  </li>
                  <li>
                    <Link href="/tramites/traslados" className="text-primary hover:underline flex items-center gap-2">
                      <span className="h-1.5 w-1.5 rounded-full bg-primary"></span>
                      Traslados
                    </Link>
                  </li>
                </ul>
                <Button variant="outline" asChild className="mt-4 w-full">
                  <Link href="/tramites">Ver todos los trámites</Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Virtual Assistant */}
      <VirtualAssistant />
    </main>
  )
}

function QuickAccessCard({ href, icon, title }: { href: string; icon: React.ReactNode; title: string }) {
  return (
    <Link
      href={href}
      className="flex flex-col items-center justify-center p-4 bg-card rounded-lg shadow-sm hover:shadow-md transition-all duration-200 hover:bg-primary/5"
    >
      <div className="text-primary mb-2">{icon}</div>
      <span className="text-center font-medium">{title}</span>
    </Link>
  )
}

