import type React from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Download, CheckCircle, AlertCircle } from "lucide-react"

export default function InscripcionesPage() {
  return (
    <main className="container py-12">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold mb-6">Inscripciones</h1>
        <p className="text-xl text-muted-foreground mb-8">
          Bienvenido al proceso de inscripción de la Institución Educativa Distrital Juan Acosta Solera. Aquí
          encontrarás toda la información necesaria para inscribir a tu hijo/a en nuestra institución.
        </p>

        <Tabs defaultValue="nuevos" className="mb-12">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="nuevos">Estudiantes Nuevos</TabsTrigger>
            <TabsTrigger value="antiguos">Estudiantes Antiguos</TabsTrigger>
          </TabsList>

          <TabsContent value="nuevos">
            <Card>
              <CardHeader>
                <CardTitle>Proceso de Inscripción para Estudiantes Nuevos</CardTitle>
                <CardDescription>
                  Sigue estos pasos para inscribir a un nuevo estudiante en nuestra institución.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Requisitos</h3>
                  <ul className="space-y-2">
                    <RequirementItem>Registro civil de nacimiento</RequirementItem>
                    <RequirementItem>Documento de identidad del estudiante</RequirementItem>
                    <RequirementItem>Documento de identidad de los padres o acudientes</RequirementItem>
                    <RequirementItem>Certificado de afiliación a EPS</RequirementItem>
                    <RequirementItem>Certificado de notas del año anterior</RequirementItem>
                    <RequirementItem>Paz y salvo del colegio anterior</RequirementItem>
                    <RequirementItem>Dos fotografías recientes tamaño carné</RequirementItem>
                    <RequirementItem>Certificado de vacunación (para preescolar y primaria)</RequirementItem>
                  </ul>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Pasos a Seguir</h3>
                  <ol className="space-y-4">
                    <ProcessStep
                      number={1}
                      title="Descargar y completar el formulario de inscripción"
                      description="Descarga el formulario, complétalo con la información solicitada y fírmalo."
                    >
                      <Button variant="outline" className="mt-2">
                        <Download className="mr-2 h-4 w-4" />
                        Descargar Formulario
                      </Button>
                    </ProcessStep>

                    <ProcessStep
                      number={2}
                      title="Reunir documentación requerida"
                      description="Prepara todos los documentos mencionados en la sección de requisitos."
                    />

                    <ProcessStep
                      number={3}
                      title="Entregar documentación"
                      description="Presenta la documentación completa en la secretaría de la institución en el horario de atención."
                    />

                    <ProcessStep
                      number={4}
                      title="Entrevista"
                      description="Asiste a la entrevista programada con el estudiante."
                    />

                    <ProcessStep
                      number={5}
                      title="Confirmación de admisión"
                      description="Espera la notificación de admisión que será enviada al correo electrónico registrado."
                    />

                    <ProcessStep
                      number={6}
                      title="Matrícula"
                      description="Una vez admitido, realiza el proceso de matrícula en las fechas establecidas."
                    />
                  </ol>
                </div>

                <div className="bg-muted p-4 rounded-lg">
                  <h3 className="text-lg font-semibold mb-2">Fechas Importantes</h3>
                  <ul className="space-y-2">
                    <li className="flex justify-between">
                      <span>Apertura de inscripciones:</span>
                      <span className="font-medium">15 de octubre de 2024</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Cierre de inscripciones:</span>
                      <span className="font-medium">30 de noviembre de 2024</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Entrevistas:</span>
                      <span className="font-medium">1 al 15 de diciembre de 2024</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Publicación de resultados:</span>
                      <span className="font-medium">20 de diciembre de 2024</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Período de matrículas:</span>
                      <span className="font-medium">2 al 20 de enero de 2025</span>
                    </li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="antiguos">
            <Card>
              <CardHeader>
                <CardTitle>Renovación de Matrícula para Estudiantes Antiguos</CardTitle>
                <CardDescription>
                  Información para el proceso de renovación de matrícula para el próximo año escolar.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Requisitos</h3>
                  <ul className="space-y-2">
                    <RequirementItem>Boletín final de calificaciones</RequirementItem>
                    <RequirementItem>Paz y salvo de la institución</RequirementItem>
                    <RequirementItem>Actualización de datos personales</RequirementItem>
                    <RequirementItem>Certificado actualizado de afiliación a EPS</RequirementItem>
                    <RequirementItem>Una fotografía reciente tamaño carné</RequirementItem>
                  </ul>
                </div>

                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Proceso de Renovación</h3>
                  <ol className="space-y-4">
                    <ProcessStep
                      number={1}
                      title="Actualizar datos en la plataforma"
                      description="Ingresa a la plataforma académica y actualiza la información personal del estudiante."
                    >
                      <Button className="mt-2">Ir a la Plataforma</Button>
                    </ProcessStep>

                    <ProcessStep
                      number={2}
                      title="Descargar y completar el formulario de renovación"
                      description="Descarga el formulario, complétalo con la información solicitada y fírmalo."
                    >
                      <Button variant="outline" className="mt-2">
                        <Download className="mr-2 h-4 w-4" />
                        Descargar Formulario
                      </Button>
                    </ProcessStep>

                    <ProcessStep
                      number={3}
                      title="Entregar documentación"
                      description="Presenta la documentación completa en la secretaría de la institución en el horario de atención."
                    />

                    <ProcessStep
                      number={4}
                      title="Formalizar matrícula"
                      description="Firma el acta de matrícula en la fecha asignada según el grado."
                    />
                  </ol>
                </div>

                <div className="bg-muted p-4 rounded-lg">
                  <h3 className="text-lg font-semibold mb-2">Fechas de Renovación por Grados</h3>
                  <ul className="space-y-2">
                    <li className="flex justify-between">
                      <span>Preescolar y Primaria (1° a 3°):</span>
                      <span className="font-medium">2 al 6 de enero de 2025</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Primaria (4° y 5°):</span>
                      <span className="font-medium">9 al 13 de enero de 2025</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Secundaria (6° a 8°):</span>
                      <span className="font-medium">16 al 20 de enero de 2025</span>
                    </li>
                    <li className="flex justify-between">
                      <span>Secundaria (9° a 11°):</span>
                      <span className="font-medium">23 al 27 de enero de 2025</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-yellow-50 dark:bg-yellow-950/30 border border-yellow-200 dark:border-yellow-900 p-4 rounded-lg flex items-start gap-3">
                  <AlertCircle className="h-5 w-5 text-yellow-600 dark:text-yellow-400 flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-yellow-800 dark:text-yellow-300">Importante</h4>
                    <p className="text-yellow-700 dark:text-yellow-400 text-sm">
                      La renovación de matrícula debe realizarse en las fechas establecidas. De no hacerlo, la
                      institución dispondrá del cupo para nuevos estudiantes.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="bg-primary/5 rounded-lg p-6">
          <h2 className="text-2xl font-bold mb-4">¿Necesitas ayuda?</h2>
          <p className="mb-4">
            Si tienes dudas sobre el proceso de inscripción o renovación de matrícula, puedes contactarnos a través de
            los siguientes medios:
          </p>
          <div className="space-y-2">
            <p>
              <strong>Teléfono:</strong> (+57) 300 123 4567
            </p>
            <p>
              <strong>Correo electrónico:</strong> inscripciones@inedjas.edu.co
            </p>
            <p>
              <strong>Horario de atención:</strong> Lunes a viernes de 8:00 AM a 3:00 PM
            </p>
          </div>
        </div>
      </div>
    </main>
  )
}

function RequirementItem({ children }: { children: React.ReactNode }) {
  return (
    <li className="flex items-start gap-2">
      <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
      <span>{children}</span>
    </li>
  )
}

function ProcessStep({
  number,
  title,
  description,
  children,
}: {
  number: number
  title: string
  description: string
  children?: React.ReactNode
}) {
  return (
    <li className="border-l-2 border-primary pl-6 pb-2 relative">
      <div className="absolute -left-[11px] -top-[2px] bg-background p-1">
        <div className="h-5 w-5 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold">
          {number}
        </div>
      </div>
      <h4 className="font-semibold">{title}</h4>
      <p className="text-muted-foreground text-sm">{description}</p>
      {children}
    </li>
  )
}

