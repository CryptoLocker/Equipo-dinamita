import type React from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Facebook, Instagram, Twitter, Youtube, Mail, Phone, MapPin } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-muted/50 pt-12 pb-6">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-bold mb-4">INEDJAS</h3>
            <p className="text-muted-foreground mb-4">
              Institución Educativa Distrital Juan Acosta Solera, comprometida con la formación integral de nuestros
              estudiantes.
            </p>
            <div className="flex space-x-4">
              <SocialLink href="https://facebook.com" icon={<Facebook size={18} />} label="Facebook" />
              <SocialLink href="https://instagram.com" icon={<Instagram size={18} />} label="Instagram" />
              <SocialLink href="https://twitter.com" icon={<Twitter size={18} />} label="Twitter" />
              <SocialLink href="https://youtube.com" icon={<Youtube size={18} />} label="YouTube" />
            </div>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">Enlaces Rápidos</h3>
            <ul className="space-y-2">
              <FooterLink href="/inscripciones">Inscripciones</FooterLink>
              <FooterLink href="/plataforma">Plataforma Académica</FooterLink>
              <FooterLink href="/convivencia">Manual de Convivencia</FooterLink>
              <FooterLink href="/emisora">Emisora Escolar</FooterLink>
              <FooterLink href="/periodico">Periódico Escolar</FooterLink>
              <FooterLink href="/calendario">Calendario</FooterLink>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">Contacto</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-2">
                <MapPin size={18} className="text-primary mt-0.5 flex-shrink-0" />
                <span className="text-muted-foreground">Calle 123 #45-67, Barranquilla, Colombia</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone size={18} className="text-primary flex-shrink-0" />
                <span className="text-muted-foreground">(+57) 300 123 4567</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail size={18} className="text-primary flex-shrink-0" />
                <span className="text-muted-foreground">contacto@inedjas.edu.co</span>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">Boletín Informativo</h3>
            <p className="text-muted-foreground mb-4">
              Suscríbase para recibir noticias y actualizaciones de nuestra institución.
            </p>
            <div className="flex flex-col space-y-2">
              <Input placeholder="Correo electrónico" type="email" />
              <Button>Suscribirse</Button>
            </div>
          </div>
        </div>

        <div className="border-t border-border mt-8 pt-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-muted-foreground text-center md:text-left">
              © {new Date().getFullYear()} Institución Educativa Distrital Juan Acosta Solera. Todos los derechos
              reservados.
            </p>
            <div className="flex space-x-4 text-sm">
              <Link href="/privacidad" className="text-muted-foreground hover:text-foreground transition-colors">
                Política de Privacidad
              </Link>
              <Link href="/terminos" className="text-muted-foreground hover:text-foreground transition-colors">
                Términos de Uso
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}

function SocialLink({ href, icon, label }: { href: string; icon: React.ReactNode; label: string }) {
  return (
    <Link
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="h-8 w-8 flex items-center justify-center rounded-full bg-background hover:bg-primary/10 transition-colors"
      aria-label={label}
    >
      <span className="text-foreground">{icon}</span>
    </Link>
  )
}

function FooterLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <li>
      <Link href={href} className="text-muted-foreground hover:text-foreground hover:underline transition-colors">
        {children}
      </Link>
    </li>
  )
}

