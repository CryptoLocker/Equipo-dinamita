"use client"

import React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { ThemeToggle } from "@/components/theme-toggle"
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu"
import { cn } from "@/lib/utils"
import { Menu, X } from "lucide-react"
import { useMobile } from "@/hooks/use-mobile"

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const pathname = usePathname()
  const isMobile = useMobile()

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header
      className={cn(
        "sticky top-0 z-50 w-full transition-all duration-200",
        isScrolled ? "bg-background/95 backdrop-blur-sm shadow-sm" : "bg-transparent",
      )}
    >
      <div className="container flex h-16 items-center justify-between">
        <Link href="/" className="flex items-center space-x-2">
          <div className="relative h-10 w-10 overflow-hidden rounded-full">
            <Image src="/placeholder.svg?height=40&width=40" alt="INEDJAS Logo" fill className="object-cover" />
          </div>
          <span className="font-bold text-xl hidden sm:inline-block">INEDJAS</span>
        </Link>

        {isMobile ? (
          <>
            <Button variant="ghost" size="icon" onClick={() => setIsMenuOpen(!isMenuOpen)} aria-label="Toggle menu">
              {isMenuOpen ? <X /> : <Menu />}
            </Button>
            {isMenuOpen && (
              <div className="fixed inset-0 top-16 bg-background z-40 p-4 overflow-y-auto">
                <nav className="space-y-4">
                  <MobileNavLink href="/" active={pathname === "/"} onClick={() => setIsMenuOpen(false)}>
                    Inicio
                  </MobileNavLink>
                  <MobileNavLink
                    href="/inscripciones"
                    active={pathname === "/inscripciones"}
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Inscripciones
                  </MobileNavLink>
                  <MobileNavLink
                    href="/plataforma"
                    active={pathname === "/plataforma"}
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Plataforma Académica
                  </MobileNavLink>
                  <MobileNavLink
                    href="/convivencia"
                    active={pathname === "/convivencia"}
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Manual de Convivencia
                  </MobileNavLink>
                  <MobileNavLink href="/emisora" active={pathname === "/emisora"} onClick={() => setIsMenuOpen(false)}>
                    Emisora Escolar
                  </MobileNavLink>
                  <MobileNavLink
                    href="/periodico"
                    active={pathname === "/periodico"}
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Periódico Escolar
                  </MobileNavLink>
                  <MobileNavLink
                    href="/calendario"
                    active={pathname === "/calendario"}
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Calendario
                  </MobileNavLink>
                  <MobileNavLink
                    href="/tramites"
                    active={pathname === "/tramites"}
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Trámites
                  </MobileNavLink>
                  <MobileNavLink href="/acerca" active={pathname === "/acerca"} onClick={() => setIsMenuOpen(false)}>
                    Acerca de
                  </MobileNavLink>
                  <MobileNavLink href="/galeria" active={pathname === "/galeria"} onClick={() => setIsMenuOpen(false)}>
                    Galería
                  </MobileNavLink>
                  <MobileNavLink
                    href="/contacto"
                    active={pathname === "/contacto"}
                    onClick={() => setIsMenuOpen(false)}
                  >
                    Contacto
                  </MobileNavLink>
                </nav>
                <div className="mt-6 flex justify-center">
                  <ThemeToggle />
                </div>
              </div>
            )}
          </>
        ) : (
          <div className="flex items-center gap-4">
            <NavigationMenu>
              <NavigationMenuList>
                <NavigationMenuItem>
                  <Link href="/" legacyBehavior passHref>
                    <NavigationMenuLink className={navigationMenuTriggerStyle()}>Inicio</NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <NavigationMenuTrigger>Académico</NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px]">
                      <ListItem href="/inscripciones" title="Inscripciones">
                        Proceso de inscripción y matrícula para nuevos estudiantes
                      </ListItem>
                      <ListItem href="/plataforma" title="Plataforma Académica">
                        Acceso al sistema de gestión académica
                      </ListItem>
                      <ListItem href="/convivencia" title="Manual de Convivencia">
                        Normas y reglamentos de la institución
                      </ListItem>
                      <ListItem href="/calendario" title="Calendario">
                        Eventos y actividades programadas
                      </ListItem>
                    </ul>
                  </NavigationMenuContent>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <NavigationMenuTrigger>Comunicación</NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px]">
                      <ListItem href="/emisora" title="Emisora Escolar">
                        Programación y contenidos de nuestra emisora
                      </ListItem>
                      <ListItem href="/periodico" title="Periódico Escolar">
                        Noticias y artículos escritos por nuestra comunidad
                      </ListItem>
                      <ListItem href="/noticias" title="Noticias y Eventos">
                        Últimas novedades de nuestra institución
                      </ListItem>
                      <ListItem href="/contacto" title="Contacto">
                        Información de contacto y redes sociales
                      </ListItem>
                    </ul>
                  </NavigationMenuContent>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <NavigationMenuTrigger>Institución</NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2 lg:w-[600px]">
                      <ListItem href="/acerca" title="Acerca de">
                        Historia, misión, visión y valores institucionales
                      </ListItem>
                      <ListItem href="/galeria" title="Galería">
                        Fotos y videos de nuestras instalaciones y eventos
                      </ListItem>
                      <ListItem href="/tramites" title="Trámites">
                        Gestión de certificados y documentos administrativos
                      </ListItem>
                      <ListItem href="/feedback" title="Feedback">
                        Comparta sus opiniones y sugerencias
                      </ListItem>
                    </ul>
                  </NavigationMenuContent>
                </NavigationMenuItem>
              </NavigationMenuList>
            </NavigationMenu>
            <ThemeToggle />
            <Button asChild>
              <Link href="/plataforma">Acceder</Link>
            </Button>
          </div>
        )}
      </div>
    </header>
  )
}

function MobileNavLink({
  href,
  children,
  active,
  onClick,
}: {
  href: string
  children: React.ReactNode
  active: boolean
  onClick: () => void
}) {
  return (
    <Link
      href={href}
      className={cn(
        "block py-2 px-4 rounded-md transition-colors",
        active ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted",
      )}
      onClick={onClick}
    >
      {children}
    </Link>
  )
}

const ListItem = React.forwardRef<React.ElementRef<"a">, React.ComponentPropsWithoutRef<"a">>(
  ({ className, title, children, ...props }, ref) => {
    return (
      <li>
        <NavigationMenuLink asChild>
          <a
            ref={ref}
            className={cn(
              "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground",
              className,
            )}
            {...props}
          >
            <div className="text-sm font-medium leading-none">{title}</div>
            <p className="line-clamp-2 text-sm leading-snug text-muted-foreground">{children}</p>
          </a>
        </NavigationMenuLink>
      </li>
    )
  },
)
ListItem.displayName = "ListItem"

