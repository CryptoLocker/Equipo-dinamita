"use client"

import { useEffect, useState } from "react"
import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"
import { Moon, Sun } from "lucide-react"

export function ThemeToggle() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)

  // Auto-switch theme based on time
  useEffect(() => {
    setMounted(true)

    const autoSwitchTheme = () => {
      const currentHour = new Date().getHours()
      // Switch to dark mode between 6 PM and 6 AM
      if (currentHour >= 18 || currentHour < 6) {
        setTheme("dark")
      } else {
        setTheme("light")
      }
    }

    // Initial check
    autoSwitchTheme()

    // Check every hour
    const interval = setInterval(autoSwitchTheme, 60 * 60 * 1000)

    return () => clearInterval(interval)
  }, [setTheme])

  if (!mounted) {
    return null
  }

  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={() => setTheme(theme === "light" ? "dark" : "light")}
      aria-label="Toggle theme"
    >
      <Sun className="h-[1.2rem] w-[1.2rem] rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
      <Moon className="absolute h-[1.2rem] w-[1.2rem] rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
    </Button>
  )
}

