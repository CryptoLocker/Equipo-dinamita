"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Bot, Send, X } from "lucide-react"

export default function VirtualAssistant() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "¡Hola! Soy el asistente virtual de INEDJAS. ¿En qué puedo ayudarte hoy?",
    },
  ])
  const [input, setInput] = useState("")

  const handleSend = () => {
    if (!input.trim()) return

    // Add user message
    const userMessage: Message = {
      role: "user",
      content: input,
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")

    // Simulate assistant response
    setTimeout(() => {
      const response = getAssistantResponse(input)
      setMessages((prev) => [...prev, response])
    }, 1000)
  }

  const getAssistantResponse = (query: string): Message => {
    const lowerQuery = query.toLowerCase()

    if (lowerQuery.includes("inscripción") || lowerQuery.includes("matricula")) {
      return {
        role: "assistant",
        content:
          "Para inscripciones y matrículas, debes visitar la sección de Inscripciones en nuestro sitio web. Allí encontrarás los formularios necesarios y los requisitos para el proceso.",
      }
    } else if (lowerQuery.includes("horario") || lowerQuery.includes("atención")) {
      return {
        role: "assistant",
        content:
          "Nuestro horario de atención es de lunes a viernes de 7:00 AM a 4:00 PM, y los sábados de 8:00 AM a 12:00 PM.",
      }
    } else if (lowerQuery.includes("contacto") || lowerQuery.includes("teléfono") || lowerQuery.includes("dirección")) {
      return {
        role: "assistant",
        content:
          "Puedes contactarnos al teléfono (+57) 300 123 4567 o visitarnos en Calle 123 #45-67, Barranquilla, Colombia. También puedes escribirnos a contacto@inedjas.edu.co.",
      }
    } else if (lowerQuery.includes("plataforma") || lowerQuery.includes("académica") || lowerQuery.includes("notas")) {
      return {
        role: "assistant",
        content:
          "Para acceder a la plataforma académica, debes hacer clic en el botón 'Acceder' en la parte superior de la página. Allí podrás consultar tus calificaciones, tareas y recursos educativos.",
      }
    } else if (lowerQuery.includes("emisora") || lowerQuery.includes("radio")) {
      return {
        role: "assistant",
        content:
          "Nuestra emisora escolar transmite de lunes a viernes durante los descansos. Puedes acceder a los programas grabados en la sección 'Emisora Escolar' de nuestro sitio web.",
      }
    } else if (lowerQuery.includes("periódico") || lowerQuery.includes("noticias")) {
      return {
        role: "assistant",
        content:
          "El periódico escolar se publica mensualmente. Puedes leer las ediciones actuales y anteriores en la sección 'Periódico Escolar' de nuestro sitio web.",
      }
    } else if (lowerQuery.includes("calendario") || lowerQuery.includes("eventos")) {
      return {
        role: "assistant",
        content:
          "Puedes consultar nuestro calendario de eventos en la sección 'Calendario' del sitio web. Allí encontrarás todas las actividades programadas para el año escolar.",
      }
    } else if (lowerQuery.includes("gracias")) {
      return {
        role: "assistant",
        content: "¡De nada! Estoy aquí para ayudarte. Si tienes más preguntas, no dudes en consultarme.",
      }
    } else {
      return {
        role: "assistant",
        content:
          "No tengo información específica sobre esa consulta. Te recomiendo visitar las diferentes secciones de nuestro sitio web o contactar directamente con la institución para obtener más detalles.",
      }
    }
  }

  return (
    <>
      <Button
        className="fixed bottom-6 right-6 rounded-full h-14 w-14 shadow-lg"
        onClick={() => setIsOpen(true)}
        aria-label="Abrir asistente virtual"
      >
        <Bot className="h-6 w-6" />
      </Button>

      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetContent className="w-full sm:max-w-md p-0 flex flex-col h-full">
          <SheetHeader className="p-4 border-b">
            <div className="flex justify-between items-center">
              <SheetTitle>Asistente Virtual INEDJAS</SheetTitle>
              <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
            <SheetDescription>Estoy aquí para responder tus preguntas sobre nuestra institución.</SheetDescription>
          </SheetHeader>

          <ScrollArea className="flex-1 p-4">
            <div className="space-y-4">
              {messages.map((message, index) => (
                <div key={index} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-[80%] rounded-lg p-3 ${
                      message.role === "user" ? "bg-primary text-primary-foreground" : "bg-muted"
                    }`}
                  >
                    {message.content}
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>

          <div className="p-4 border-t">
            <form
              onSubmit={(e) => {
                e.preventDefault()
                handleSend()
              }}
              className="flex gap-2"
            >
              <Input
                placeholder="Escribe tu pregunta..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className="flex-1"
              />
              <Button type="submit" size="icon">
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </div>
        </SheetContent>
      </Sheet>
    </>
  )
}

interface Message {
  role: "user" | "assistant"
  content: string
}

