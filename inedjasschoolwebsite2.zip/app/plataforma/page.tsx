import type React from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { BookOpen, Calendar, FileText, GraduationCap, MessageSquare, User } from "lucide-react"

export default function PlataformaPage() {
  return (
    <main className="container py-12">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-4xl font-bold mb-6">Plataforma Académica</h1>
        <p className="text-xl text-muted-foreground mb-8">
          Accede a nuestra plataforma académica para consultar calificaciones, tareas, recursos educativos y más.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          <Card className="md:col-span-1">
            <CardHeader>
              <CardTitle>Iniciar Sesión</CardTitle>
              <CardDescription>Ingresa tus credenciales para acceder a la plataforma académica.</CardDescription>
            </CardHeader>
            <CardContent>
              <form>
                <div className="grid gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="username">Usuario</Label>
                    <Input id="username" placeholder="Ingresa tu nombre de usuario" />
                  </div>
                  <div className="grid gap-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="password">Contraseña</Label>
                      <Link href="/recuperar-contrasena" className="text-sm text-primary hover:underline">
                        ¿Olvidaste tu contraseña?
                      </Link>
                    </div>
                    <Input id="password" type="password" placeholder="Ingresa tu contraseña" />
                  </div>
                </div>
              </form>
            </CardContent>
            <CardFooter>
              <Button className="w-full">Iniciar Sesión</Button>
            </CardFooter>
          </Card>

          <Card className="md:col-span-1">
            <CardHeader>
              <CardTitle>Información de Acceso</CardTitle>
              <CardDescription>Información importante sobre el acceso a la plataforma académica.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-muted p-4 rounded-lg">
                <h3 className="font-semibold mb-2">Estudiantes</h3>
                <p className="text-sm text-muted-foreground">
                  El nombre de usuario es el número de documento del estudiante. La contraseña inicial es la fecha de
                  nacimiento en formato DDMMAAAA.
                </p>
              </div>
              <div className="bg-muted p-4 rounded-lg">
                <h3 className="font-semibold mb-2">Padres y Acudientes</h3>
                <p className="text-sm text-muted-foreground">
                  El nombre de usuario es el número de documento del padre o acudiente. La contraseña inicial es el
                  número de documento del estudiante.
                </p>
              </div>
              <div className="bg-muted p-4 rounded-lg">
                <h3 className="font-semibold mb-2">Docentes</h3>
                <p className="text-sm text-muted-foreground">
                  El nombre de usuario es el correo institucional. La contraseña inicial es proporcionada por el
                  coordinador académico.
                </p>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" asChild>
                <Link href="/soporte">Soporte Técnico</Link>
              </Button>
              <Button variant="outline" asChild>
                <Link href="/manual-usuario">Manual de Usuario</Link>
              </Button>
            </CardFooter>
          </Card>
        </div>

        <h2 className="text-2xl font-bold mb-4">Funcionalidades de la Plataforma</h2>
        <Tabs defaultValue="estudiantes" className="mb-12">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="estudiantes">Estudiantes</TabsTrigger>
            <TabsTrigger value="padres">Padres</TabsTrigger>
            <TabsTrigger value="docentes">Docentes</TabsTrigger>
          </TabsList>

          <TabsContent value="estudiantes">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <FeatureCard
                icon={<FileText className="h-8 w-8" />}
                title="Calificaciones"
                description="Consulta tus calificaciones por período y asignatura."
              />
              <FeatureCard
                icon={<Calendar className="h-8 w-8" />}
                title="Horario"
                description="Visualiza tu horario de clases semanal."
              />
              <FeatureCard
                icon={<BookOpen className="h-8 w-8" />}
                title="Tareas y Actividades"
                description="Accede a las tareas asignadas y fechas de entrega."
              />
              <FeatureCard
                icon={<GraduationCap className="h-8 w-8" />}
                title="Recursos Educativos"
                description="Descarga material de estudio y recursos complementarios."
              />
              <FeatureCard
                icon={<MessageSquare className="h-8 w-8" />}
                title="Mensajería"
                description="Comunícate con tus profesores y compañeros."
              />
              <FeatureCard
                icon={<User className="h-8 w-8" />}
                title="Perfil"
                description="Actualiza tu información personal y contraseña."
              />
            </div>
          </TabsContent>

          <TabsContent value="padres">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <FeatureCard
                icon={<FileText className="h-8 w-8" />}
                title="Calificaciones"
                description="Consulta las calificaciones de tus hijos por período y asignatura."
              />
              <FeatureCard
                icon={<Calendar className="h-8 w-8" />}
                title="Asistencia"
                description="Verifica la asistencia a clases de tus hijos."
              />
              <FeatureCard
                icon={<BookOpen className="h-8 w-8" />}
                title="Tareas y Actividades"
                description="Conoce las tareas asignadas y fechas de entrega."
              />
              <FeatureCard
                icon={<MessageSquare className="h-8 w-8" />}
                title="Comunicación"
                description="Comunícate con los profesores y directivos."
              />
              <FeatureCard
                icon={<Calendar className="h-8 w-8" />}
                title="Calendario"
                description="Consulta fechas importantes y reuniones programadas."
              />
              <FeatureCard
                icon={<User className="h-8 w-8" />}
                title="Perfil"
                description="Actualiza tu información de contacto y contraseña."
              />
            </div>
          </TabsContent>

          <TabsContent value="docentes">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <FeatureCard
                icon={<FileText className="h-8 w-8" />}
                title="Registro de Calificaciones"
                description="Registra y gestiona las calificaciones de tus estudiantes."
              />
              <FeatureCard
                icon={<Calendar className="h-8 w-8" />}
                title="Control de Asistencia"
                description="Registra la asistencia de los estudiantes a tus clases."
              />
              <FeatureCard
                icon={<BookOpen className="h-8 w-8" />}
                title="Asignación de Tareas"
                description="Crea y asigna tareas y actividades a tus grupos."
              />
              <FeatureCard
                icon={<GraduationCap className="h-8 w-8" />}
                title="Recursos Educativos"
                description="Comparte material de estudio y recursos con tus estudiantes."
              />
              <FeatureCard
                icon={<MessageSquare className="h-8 w-8" />}
                title="Comunicación"
                description="Comunícate con estudiantes, padres y otros docentes."
              />
              <FeatureCard
                icon={<User className="h-8 w-8" />}
                title="Perfil"
                description="Actualiza tu información profesional y contraseña."
              />
            </div>
          </TabsContent>
        </Tabs>

        <div className="bg-primary/5 rounded-lg p-6">
          <h2 className="text-2xl font-bold mb-4">Preguntas Frecuentes</h2>
          <div className="space-y-4">
            <div>
              <h3 className="font-semibold">¿Cómo recupero mi contraseña?</h3>
              <p className="text-muted-foreground">
                Puedes recuperar tu contraseña haciendo clic en "¿Olvidaste tu contraseña?" en la página de inicio de
                sesión. Recibirás un correo electrónico con instrucciones para restablecerla.
              </p>
            </div>
            <div>
              <h3 className="font-semibold">¿Cómo actualizo mi información personal?</h3>
              <p className="text-muted-foreground">
                Una vez que hayas iniciado sesión, ve a la sección "Perfil" donde podrás actualizar tu información
                personal y de contacto.
              </p>
            </div>
            <div>
              <h3 className="font-semibold">¿Qué hago si no puedo acceder a la plataforma?</h3>
              <p className="text-muted-foreground">
                Si tienes problemas para acceder, contacta al soporte técnico a través del correo soporte@inedjas.edu.co
                o llama al (+57) 300 123 4567.
              </p>
            </div>
            <div>
              <h3 className="font-semibold">¿Con qué frecuencia se actualizan las calificaciones?</h3>
              <p className="text-muted-foreground">
                Las calificaciones se actualizan semanalmente. Los docentes tienen hasta el viernes de cada semana para
                registrar las calificaciones de la semana.
              </p>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}

function FeatureCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode
  title: string
  description: string
}) {
  return (
    <Card className="h-full">
      <CardHeader className="pb-2">
        <div className="text-primary mb-2">{icon}</div>
        <CardTitle className="text-lg">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <CardDescription>{description}</CardDescription>
      </CardContent>
    </Card>
  )
}

