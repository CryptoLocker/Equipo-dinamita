import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"

export default function HeroSection() {
  return (
    <section className="relative py-20 md:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-primary/20 via-accent/10 to-secondary/10 dark:from-primary/20 dark:via-accent/5 dark:to-secondary/5 z-0"></div>
      <div className="container relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 text-primary">
            Institución Educativa Distrital Juan Acosta Solera
          </h1>

          {/* Logo circular e interactivo */}
          <div className="flex justify-center mb-6">
            <div className="relative w-32 h-32 md:w-40 md:h-40 rounded-full overflow-hidden border-4 border-accent transition-transform duration-300 hover:scale-110 cursor-pointer shadow-md">
              <Image
                src="/logo-inedjas.png"
                alt="Logo INEDJAS"
                fill
                className="object-contain p-2 rounded-full"
                priority
              />
            </div>
          </div>

          <p className="text-xl md:text-2xl text-muted-foreground mb-8">
            Formando líderes para el futuro con educación de calidad
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-primary hover:bg-primary/90" asChild>
              <Link href="/plataforma">Plataforma Académica</Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-accent text-accent-foreground hover:bg-accent/10"
              asChild
            >
              <Link href="/acerca">Conocer más</Link>
            </Button>
          </div>
        </div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-background to-transparent"></div>
    </section>
  )
}

